!(function () {
  "use strict";
  const e = "__HS__FORMS__EMBED__",
    t = "HubSpotFormsV4",
    s = "HubspotFormsV4",
    n = "__SECRET_INTERNAL_DO_NOT_USE";
  var i = {
    mode: "compressed",
    staticDomainPrefix: "//static.hsappstatic.net",
    bender: {
      depVersions: {
        "ui-forms-embed-components-frame-parent": "static-1.1764",
        "hs-lodash": "static-4.45",
        "hs-test-utils": "static-1.8227",
        HubStyleTokens: "static-2.11678",
        "jasmine-runner": "static-1.6658",
        quartz: "static-1.7301",
        react: "static-7.190",
        "web-interactives-embed-framework": "static-2.5540",
        "hubspot-url-utils": "static-1.4277",
        outpost: "static-1.4370",
        "ui-forms-embed-components-performance": "static-1.1820",
        "ui-forms-embed-components-library": "static-1.7134",
        "ui-forms-embed-components-reporting": "static-1.6612",
        "bend-plugin-trellis-migration": "static-1.3541",
        "foundations-components": "static-1.8312",
        "framer-motion": "static-1.75",
        "hs-test-utils-bend-plugin": "static-1.3338",
        msw: "static-1.39",
        "react-dom": "static-7.85",
        "react-redux": "static-7.75",
        redux: "static-4.16",
        "testing-library": "static-1.155",
        "foundations-theming": "static-1.4645",
        "quartz-config": "static-1.1079",
        jasmine: "static-4.4527",
        "webpack-env": "static-1.54",
        csstype: "static-1.50",
        "quartz-core": "static-1.6520",
        enviro: "static-4.476",
        classnames: "static-2.10",
        "hs-story-utils": "static-1.9630",
        "styled-components": "static-2.93",
        StyleGuideUI: "static-3.491",
        "bender-build-tools": "static-1.3322",
        "bend-plugin-foundations-components": "static-1.4581",
        "floating-ui": "static-1.60",
        "foundations-assets": "static-1.5079",
        "foundations-theming-specialty": "static-1.2361",
        I18n: "static-7.1650",
        "metrics-js": "static-1.9843",
        moment: "static-3.26",
        "react-aria": "static-1.69",
        "react-create-root-preference": "static-1.50",
        "react-select-plus": "static-1.108",
        "react-utils": "static-2.5482",
        "react-virtualized": "static-2.102",
        "tanstack-table": "static-1.58",
        "trellis-assets": "static-1.2341",
        "ui-fonts": "static-1.940",
        "ui-images": "static-2.1212",
        "hoist-non-react-statics": "static-3.9",
        "bend-plugin-foundations-theming": "static-1.3128",
        "foundations-theming-base": "static-1.3630",
        stylex: "static-1.37",
        dispatcher: "static-1.140",
        "general-store": "static-6.20",
        HeadJS: "static-2.781",
        "hub-http": "static-1.6421",
        "hub-http-janus": "static-1.858",
        "hubspotter-http": "static-1.4792",
        icons: "static-2.668",
        "mobile-manifest-mixins": "static-1.555",
        "module-federation": "static-1.29",
        PortalIdParser: "static-2.425",
        "quartz-auth": "static-1.976",
        "quartz-head": "static-1.966",
        "quartz-i18n": "static-1.976",
        "quartz-routing": "static-1.731",
        "quartz-test": "static-1.976",
        "quartz-tracking": "static-1.680",
        "quick-fetch": "static-1.4059",
        raven: "static-3.6134",
        "raven-hubspot": "static-1.6441",
        "react-rhumb": "static-1-aeastham-base-reporter-resolved-tracking.4",
        "trellis-components": "static-1.2360",
        UIComponents: "static-3.8624",
        "usage-tracker-container":
          "static-1-session-replay-endpoint-migration.6",
        "usage-tracker-core": "static-1-session-replay-endpoint-migration.6",
        "web-vitals": "static-1.9",
        "i18n-data": "static-1.225",
        "moment-timezone": "static-5.86",
        "react-input-autosize": "static-2.17",
        "hs-locale-management": "static-1.222",
        sassPrefix: "static-1.160",
        "hub-http-shared-msw-handlers": "static-1.10449",
        "hubspotter-http-shared-msw-handlers": "static-1.10447",
        "hs-promise-rejection-tracking": "static-1.5792",
        "usage-tracker-session-replay":
          "static-1-session-replay-endpoint-migration.6",
        "base-ui": "static-1.17",
        "react-day-picker": "static-1.6",
        "trellis-theming": "static-1.1155",
        "tanstack-virtual": "static-1.33",
        cssUtils: "static-1.851",
        "head-dlb": "static-1.5007",
        HubStyle: "static-2.11985",
        "amplitude-session-replay-browser": "static-1.60",
        "ts-schema": "static-1.4221",
      },
      depPathPrefixes: {
        "ui-forms-embed-components-frame-parent":
          "/ui-forms-embed-components-frame-parent/static-1.1764",
        "hs-lodash": "/hs-lodash/static-4.45",
        "hs-test-utils": "/hs-test-utils/static-1.8227",
        HubStyleTokens: "/HubStyleTokens/static-2.11678",
        "jasmine-runner": "/jasmine-runner/static-1.6658",
        quartz: "/quartz/static-1.7301",
        react: "/react/static-7.190",
        "web-interactives-embed-framework":
          "/web-interactives-embed-framework/static-2.5540",
        "hubspot-url-utils": "/hubspot-url-utils/static-1.4277",
        outpost: "/outpost/static-1.4370",
        "ui-forms-embed-components-performance":
          "/ui-forms-embed-components-performance/static-1.1820",
        "ui-forms-embed-components-library":
          "/ui-forms-embed-components-library/static-1.7134",
        "ui-forms-embed-components-reporting":
          "/ui-forms-embed-components-reporting/static-1.6612",
        "bend-plugin-trellis-migration":
          "/bend-plugin-trellis-migration/static-1.3541",
        "foundations-components": "/foundations-components/static-1.8312",
        "framer-motion": "/framer-motion/static-1.75",
        "hs-test-utils-bend-plugin": "/hs-test-utils-bend-plugin/static-1.3338",
        msw: "/msw/static-1.39",
        "react-dom": "/react-dom/static-7.85",
        "react-redux": "/react-redux/static-7.75",
        redux: "/redux/static-4.16",
        "testing-library": "/testing-library/static-1.155",
        "foundations-theming": "/foundations-theming/static-1.4645",
        "quartz-config": "/quartz-config/static-1.1079",
        jasmine: "/jasmine/static-4.4527",
        "webpack-env": "/webpack-env/static-1.54",
        csstype: "/csstype/static-1.50",
        "quartz-core": "/quartz-core/static-1.6520",
        enviro: "/enviro/static-4.476",
        classnames: "/classnames/static-2.10",
        "hs-story-utils": "/hs-story-utils/static-1.9630",
        "styled-components": "/styled-components/static-2.93",
        StyleGuideUI: "/StyleGuideUI/static-3.491",
        "bender-build-tools": "/bender-build-tools/static-1.3322",
        "bend-plugin-foundations-components":
          "/bend-plugin-foundations-components/static-1.4581",
        "floating-ui": "/floating-ui/static-1.60",
        "foundations-assets": "/foundations-assets/static-1.5079",
        "foundations-theming-specialty":
          "/foundations-theming-specialty/static-1.2361",
        I18n: "/I18n/static-7.1650",
        "metrics-js": "/metrics-js/static-1.9843",
        moment: "/moment/static-3.26",
        "react-aria": "/react-aria/static-1.69",
        "react-create-root-preference":
          "/react-create-root-preference/static-1.50",
        "react-select-plus": "/react-select-plus/static-1.108",
        "react-utils": "/react-utils/static-2.5482",
        "react-virtualized": "/react-virtualized/static-2.102",
        "tanstack-table": "/tanstack-table/static-1.58",
        "trellis-assets": "/trellis-assets/static-1.2341",
        "ui-fonts": "/ui-fonts/static-1.940",
        "ui-images": "/ui-images/static-2.1212",
        "hoist-non-react-statics": "/hoist-non-react-statics/static-3.9",
        "bend-plugin-foundations-theming":
          "/bend-plugin-foundations-theming/static-1.3128",
        "foundations-theming-base": "/foundations-theming-base/static-1.3630",
        stylex: "/stylex/static-1.37",
        dispatcher: "/dispatcher/static-1.140",
        "general-store": "/general-store/static-6.20",
        HeadJS: "/HeadJS/static-2.781",
        "hub-http": "/hub-http/static-1.6421",
        "hub-http-janus": "/hub-http-janus/static-1.858",
        "hubspotter-http": "/hubspotter-http/static-1.4792",
        icons: "/icons/static-2.668",
        "mobile-manifest-mixins": "/mobile-manifest-mixins/static-1.555",
        "module-federation": "/module-federation/static-1.29",
        PortalIdParser: "/PortalIdParser/static-2.425",
        "quartz-auth": "/quartz-auth/static-1.976",
        "quartz-head": "/quartz-head/static-1.966",
        "quartz-i18n": "/quartz-i18n/static-1.976",
        "quartz-routing": "/quartz-routing/static-1.731",
        "quartz-test": "/quartz-test/static-1.976",
        "quartz-tracking": "/quartz-tracking/static-1.680",
        "quick-fetch": "/quick-fetch/static-1.4059",
        raven: "/raven/static-3.6134",
        "raven-hubspot": "/raven-hubspot/static-1.6441",
        "react-rhumb":
          "/react-rhumb/static-1-aeastham-base-reporter-resolved-tracking.4",
        "trellis-components": "/trellis-components/static-1.2360",
        UIComponents: "/UIComponents/static-3.8624",
        "usage-tracker-container":
          "/usage-tracker-container/static-1-session-replay-endpoint-migration.6",
        "usage-tracker-core":
          "/usage-tracker-core/static-1-session-replay-endpoint-migration.6",
        "web-vitals": "/web-vitals/static-1.9",
        "i18n-data": "/i18n-data/static-1.225",
        "moment-timezone": "/moment-timezone/static-5.86",
        "react-input-autosize": "/react-input-autosize/static-2.17",
        "hs-locale-management": "/hs-locale-management/static-1.222",
        sassPrefix: "/sassPrefix/static-1.160",
        "hub-http-shared-msw-handlers":
          "/hub-http-shared-msw-handlers/static-1.10449",
        "hubspotter-http-shared-msw-handlers":
          "/hubspotter-http-shared-msw-handlers/static-1.10447",
        "hs-promise-rejection-tracking":
          "/hs-promise-rejection-tracking/static-1.5792",
        "usage-tracker-session-replay":
          "/usage-tracker-session-replay/static-1-session-replay-endpoint-migration.6",
        "base-ui": "/base-ui/static-1.17",
        "react-day-picker": "/react-day-picker/static-1.6",
        "trellis-theming": "/trellis-theming/static-1.1155",
        "tanstack-virtual": "/tanstack-virtual/static-1.33",
        cssUtils: "/cssUtils/static-1.851",
        "head-dlb": "/head-dlb/static-1.5007",
        HubStyle: "/HubStyle/static-2.11985",
        "amplitude-session-replay-browser":
          "/amplitude-session-replay-browser/static-1.60",
        "ts-schema": "/ts-schema/static-1.4221",
      },
      bundlingPackage: "ui-forms-embed-components-frame-parent",
      bundlingPackageVersion: "static-1.1764",
      project: "ui-forms-embed-components-frame-parent",
      staticDomain: "//static.hsappstatic.net",
      staticDomainPrefix: "//static.hsappstatic.net",
    },
  };
  const a = {
    RECEIVED_ANALYTICS: "HS_CTA_PARENT_RECEIVED_ANALYTICS",
    DEVICE_TYPE: "HS_CTA_PARENT_DEVICE_TYPE",
    PROXY_ANALYTICS_FN_CALLBACK: "HS_CTA_PARENT_PROXY_ANALYTICS_FN",
    INIT: "HS_CTA_PARENT_INIT",
    SHOWING_CTA: "HS_CTA_SHOWING_CTA",
    SEND_EXTRACTED_STYLES: "HS_SEND_EXTRACTED_STYLES",
    STARTED: "HS_CTA_STARTED",
    NAVIGATE_PAGE: "HS_CTA_NAVIGATE_PAGE",
    CLICK_EVENT: "HS_CTA_CLICK_EVENT",
    CLOSE_INTERACTIVE: "HS_CTA_CLOSE_INTERACTIVE",
    HAS_CLOSED: "HS_CTA_HAS_CLOSED",
    NEW_HEIGHT: "HS_CTA_NEW_HEIGHT",
    DISPLAY_CALL_TO_ACTION: "HS_DISPLAY_CALL_TO_ACTION",
    PROXY_ANALYTICS: "HS_CTA_PROXY_ANALYTICS",
    PROXY_ANALYTICS_FN: "HS_CTA_PROXY_ANALYTICS_FN",
    SEND_FORM_DEFINITION: "HS_SEND_FORM_DEFINITION",
    SEND_CTA_CONFIG: "HS_SEND_CTA_CONFIG",
    SEND_EMBED_CONTEXT: "HS_SEND_EMBED_CONTEXT",
    RECEIVE_FILTERED_STYLESHEETS: "RECEIVE_FILTERED_STYLESHEETS",
    SEND_STYLESHEETS: "SEND_STYLESHEETS",
    TRIGGER_CTA: "HS_CTA_TRIGGER_CTA",
    CTA_FORM_SUBMITTED: "HS_CTA_FORM_SUBMITTED",
    V4_FORM_READY: "HS_V4_FORM_READY",
    V4_RECAPTCHA_RENDER: "HS_V4_RECAPTCHA_RENDER",
    V4_RECAPTCHA_EXECUTE: "HS_V4_RECAPTCHA_EXECUTE",
    V4_RECAPTCHA_RESET: "HS_V4_RECAPTCHA_RESET",
    V4_RECAPTCHA_SUCCESS: "HS_V4_RECAPTCHA_SUCCESS",
    V4_RECAPTCHA_EXPIRED: "HS_V4_RECAPTCHA_EXPIRED",
    V4_RECAPTCHA_ERROR: "HS_V4_RECAPTCHA_ERROR",
    SEND_FORM_EXTRA_SUBMISSION_METADATA:
      "HS_SEND_FORM_EXTRA_SUBMISSION_METADATA",
    SEND_FORM_SUBMISSION_SUCCESS_INFO: "HS_SEND_FORM_SUBMISSION_SUCCESS_INFO",
    SEND_FORM_SUBMISSION_SUCCESS: "HS_SEND_FORM_SUBMISSION_SUCCESS",
    SEND_FORM_SUBMISSION_FAILED: "HS_SEND_FORM_SUBMISSION_FAILED",
    SEND_FORM_INTERACTION_NAVIGATE: "HS_SEND_FORM_INTERACTION_NAVIGATE",
    SEND_FORM_INTERACTION_NAVIGATE_NEXT:
      "HS_SEND_FORM_INTERACTION_NAVIGATE_NEXT",
    SEND_FORM_INTERACTION_NAVIGATE_PREVIOUS:
      "HS_SEND_FORM_INTERACTION_NAVIGATE_PREVIOUS",
    GET_FORM_FIELD_VALUES: "HS_GET_FORM_FIELD_VALUES",
    SEND_FORM_FIELD_VALUES: "HS_SEND_FORM_FIELD_VALUES",
    GET_FORM_SUBMISSION_METADATA: "HS_GET_FORM_SUBMISSION_METADATA",
    SEND_FORM_SUBMISSION_METADATA: "HS_SEND_FORM_SUBMISSION_METADATA",
    GET_FIELD_VALUE: "HS_GET_FIELD_VALUE",
    SET_FIELD_VALUE: "HS_SET_FIELD_VALUE",
    SEND_FIELD_VALUE: "HS_SEND_FIELD_VALUE",
    MEETINGS_BOOKING_SUCCESS: "HS_CTA_MEETINGS_BOOKING_SUCCESS",
  };
  function r(e, t = {}) {
    for (const s in t) Object.hasOwnProperty.call(t, s) && (e.style[s] = t[s]);
  }
  function o(...e) {
    if (
      window.location.search.indexOf("hs_debug_interactive") > -1 ||
      window.location.host.includes("local.hsappstatic")
    ) {
      console.log("[web-interactives-embed]", ...e);
      window.location.search.indexOf("hs_is_selenium") > -1 &&
        console.log(...[...e].map((e) => JSON.stringify(e)));
    }
  }
  class c {
    constructor() {
      this.listeners = new Map();
    }
    on(e, t) {
      if (!this.listeners.has(e)) {
        this.listeners.set(e, [t]);
        return;
      }
      const s = this.listeners.get(e);
      this.listeners.set(e, [...s, t]);
    }
    off(e) {
      this.listeners.delete(e);
    }
    emit(e, t) {
      const s = this.listeners.get(e);
      s && s.length && s.forEach((e) => e(t));
    }
    reset() {
      this.listeners = new Map();
    }
  }
  function d() {
    return new c();
  }
  const l = (...e) => {
    o("[GlobalIframeCommunication]", ...e);
  };
  class h {
    constructor() {
      this.iframeCommunicators = new Map();
      this.eventEmitter = d();
      this.reset = () => {
        this.eventEmitter.reset();
        this.iframeCommunicators = new Map();
      };
    }
    registerHandler(e, t) {
      this.eventEmitter.on(e, t);
    }
    registerHandlers(e) {
      l("Registering handlers", e);
      Object.keys(e).forEach((t) => {
        const s = t,
          n = e[s];
        n && this.registerHandler(s, n);
      });
    }
    registerCommunicator(e, t) {
      l("Registering communicator", t);
      const s = this.iframeCommunicators.get(t) || [];
      this.iframeCommunicators.set(t, [...s, e]);
    }
    removeCommunicator(e) {
      l("Removing Iframe Communicator from GlobalCommunication: ", e);
      this.iframeCommunicators.delete(e);
    }
    emit(e, t) {
      l("Emitting event", { event: e, messagePayload: t });
      this.eventEmitter.emit(e, t);
    }
    broadcast(e, t) {
      const s = this.iframeCommunicators.get(e);
      if (s) {
        l("Broadcasting", s);
        s.forEach((e) => {
          e.sendMessage(t);
        });
      } else l("Cannot find communcators array, not broadcasting", e, t);
    }
    broadcastAll(e) {
      l("Broadcasting", e, "to all", this.iframeCommunicators);
      for (const [t, s] of this.iframeCommunicators) this.broadcast(t, e);
    }
  }
  var u = new h();
  function m() {
    return new MessageChannel();
  }
  const p = (...e) => {
    o("[iframeCommunication]", ...e);
  };
  class f {
    constructor(e, t) {
      this.queue = [];
      this.initialised = !1;
      this.events = new Map();
      this.eventEmitter = d();
      this.handleMessage = (e) => {
        if (!e.data || !e.data.type) return;
        const { type: t, payload: s } = e.data;
        p("Handling message", { type: t, payload: s });
        this.eventEmitter.emit(t, s);
        u.emit(t, Object.assign({}, s, { id: this.id }));
      };
      this.handleFrameLoaded = () => {
        if (this.iframe.contentWindow) {
          p("Iframe loaded", this.iframe);
          this.iframe.contentWindow.postMessage({ type: a.INIT }, "*", [
            this.channel.port2,
          ]);
          this.initialised = !0;
          this.flushQueue();
        } else p("Content window not there, not loading");
      };
      this.iframe = e;
      this.id = t;
      this.channel = m();
      this.channel.port1.onmessage = this.handleMessage;
      this.iframe.addEventListener("load", this.handleFrameLoaded);
      p("Iframe communication set up", t, e);
    }
    sendMessage({ type: e, payload: t }) {
      if (this.initialised) {
        p("Posting message", { type: e, payload: t });
        try {
          this.channel.port1.postMessage({ type: e, payload: t });
        } catch (s) {
          p("Dropping non-serializable message", { type: e, payload: t }, s);
        }
      } else {
        p("Queueing message", { type: e, payload: t });
        this.queue.push({ type: e, payload: t });
      }
    }
    registerHandler(e, t) {
      this.eventEmitter.on(e, t);
    }
    registerHandlers(e) {
      p("Registering handlers in IframeCommunication", e);
      Object.keys(e).forEach((t) => {
        const s = t,
          n = e[s];
        n && this.registerHandler(s, n);
      });
    }
    removeHandler(e) {
      p("Removing handler", e);
      this.eventEmitter.off(e);
    }
    remove() {
      p("Removing frame communicator:", this.id);
      this.channel.port1.close();
      u.removeCommunicator(this.id);
    }
    flushQueue() {
      if (this.initialised) {
        p("Flushing queue", this.queue);
        this.queue.forEach((e) => {
          this.sendMessage(e);
        });
      } else p("Not flushing queue, not initialised");
    }
  }
  function E(e, t) {
    p("Creating iframe communication");
    const s = new f(e, t);
    u.registerCommunicator(s, t);
    return s;
  }
  function _(e) {
    const t = window.location.origin.startsWith("http:")
      ? "http://"
      : "https://";
    return e.startsWith(t) ? e : `${t}${e.replace(/http(s)?:\/\//, "")}`;
  }
  function g(e) {
    e.style.border = "none";
    e.style.height = "100%";
    e.style.width = "100%";
    e.style.visibility = "hidden";
  }
  function b(e, t) {
    const s = document.createElement("iframe");
    s.srcdoc = e;
    Object.keys(t).forEach((e) => {
      s.setAttribute(e, t[e]);
    });
    g(s);
    return s;
  }
  function S(e, t) {
    const s = document.createElement("iframe");
    s.src = _(e);
    Object.keys(t).forEach((e) => {
      s.setAttribute(e, t[e]);
    });
    g(s);
    return s;
  }
  function I(e, t, s) {
    e.startsWith("http") || (e = `https://${e}`);
    const n = new URL(e);
    n.searchParams.set(t, s);
    return n.href;
  }
  function v(e) {
    e.startsWith("http") || (e = `https://${e}`);
    try {
      return new URL(e).searchParams.has("hs-signature");
    } catch (e) {
      return !1;
    }
  }
  const y = (...e) => {
      o("[FrameComponent]", ...e);
    },
    C = () => {};
  class A {
    constructor({
      id: e,
      container: t,
      iframeSrc: s,
      resizeHeight: n,
      onFrameReady: i,
      useResponsiveStyling: a,
      extraAttributes: r = {},
      srcdoc: o,
    }) {
      this.onFrameReady = C;
      this.resizeHeight = !0;
      this.handleHeightChange = ({ height: e }) => {
        if (!this.resizeHeight) return;
        const t =
          e + 2 * parseInt(getComputedStyle(this.iframe).borderTopWidth, 10);
        y("Handle height change", this.id, { adjustedHeight: t, height: e });
        this.setContainerStyle({ height: `${t}px` });
      };
      this.id = e;
      this.resizeHeight = n;
      if (a && s && !v(s)) {
        y("Responsive styling is enabled", e);
        s = I(s, "enableResponsiveStyles", "true");
      }
      if (s) this.iframe = S(s, r);
      else if (o) this.iframe = b(o, r);
      else {
        y("No iframeSrc or srcdoc provided, creating empty iframe", e);
        this.iframe = S("", r);
      }
      this.container = t;
      this.iframeCommunicator = E(this.iframe, e);
      i && (this.onFrameReady = i);
      t.appendChild(this.iframe);
      this.registerHandlers();
    }
    registerHandlers() {
      this.iframeCommunicator.registerHandlers({
        [a.STARTED]: this.onFrameReady,
        [a.NEW_HEIGHT]: this.handleHeightChange,
      });
    }
    setStyle(e) {
      y("Set style", this.id, e);
      r(this.iframe, e);
    }
    setShouldResize(e) {
      this.resizeHeight = e;
    }
    setContainerStyle(e) {
      r(this.container, e);
    }
  }
  function w(e) {
    return new A(e);
  }
  class T {
    constructor(e, t) {
      this.listeners = new Set();
      this.batching = !1;
      this.queue = [];
      this.subscribe = (e) => {
        this.listeners.add(e);
        let t = () => {};
        this.options &&
          this.options.onSubscribe &&
          (t = this.options.onSubscribe(e, this));
        return () => {
          this.listeners.delete(e);
          t();
        };
      };
      this.setState = (e) => {
        const t = this.state;
        this.options && this.options.updateFn
          ? (this.state = this.options.updateFn(t)(e))
          : (this.state = e(t));
        if (this.state !== t) {
          this.queue.push(() => {
            this.listeners.forEach((e) => e(this.state, t));
            this.options &&
              this.options.onUpdate &&
              this.options.onUpdate(this.state, t);
          });
          this._flush();
        }
      };
      this._flush = () => {
        if (!this.batching) {
          this.queue.forEach((e) => e());
          this.queue = [];
        }
      };
      this.batch = (e) => {
        this.batching = !0;
        e();
        this.batching = !1;
        this._flush();
      };
      this.state = e;
      this.options = t;
    }
  }
  function F(e, t = !1) {
    !window.navigator.userAgent.includes("Firefox") && t
      ? window.open(e, "_blank", "noopener")
      : window.location.assign(e);
  }
  const R = "hubspotutk",
    N = "__hstc",
    O = "__hssc",
    M = (e) => {
      const t = document.cookie.match(`(^|[^;]+)\\s*${e}\\s*=\\s*([^;]+)`);
      return t ? t.pop() : "";
    },
    D = () => M(R),
    V = () => M(N),
    P = () => M(O),
    H = (...e) => {
      o("[models/Analytics]", ...e);
    };
  class U {
    constructor() {
      this._handleFetchSucceded = (e) => {
        this.store.setState((t) => {
          const s = {};
          s.path = e.path;
          s.referrerPath = e.referrerPath;
          s.referrer = "";
          s.analyticsPageId = e.pageId;
          s.hsfp = e._getFingerprint();
          s.canonicalUrl = e.canonicalUrl;
          s.contentType = e.contentType;
          s.pageId = U.getPageId() || e.pageId;
          e.session && (s.hssc = e.session.get());
          if (e.utk) {
            s.hstc = e.utk.get();
            s.hutk = e.utk.visitor;
          }
          return Object.assign({}, t, s, { isLoaded: !0 });
        });
      };
      window._hsq = window._hsq || [];
      const e = {
        isLoaded: !1,
        pageUrl: window.location.href,
        pageTitle: window.document.title,
        referrer: window.document.referrer,
        userAgent: window.navigator.userAgent,
        hutk: D(),
        hssc: P(),
        hstc: V(),
        pageId: U.getPageId(),
      };
      this.store = new T(e);
      this.fetchAnalytics();
    }
    fetchAnalytics() {
      this._analyticsQueue.push(this._handleFetchSucceded);
    }
    refresh() {
      const e = new Promise((e) => {
          this._analyticsQueue.push((t) => {
            this._handleFetchSucceded(t);
            e();
          });
        }),
        t = new Promise((e) => setTimeout(e, 100));
      return Promise.race([e, t]);
    }
    subscribe(e) {
      return this.store.subscribe(e);
    }
    get analytics() {
      return this.store.state;
    }
    track(e) {
      H("Tracking analytics", e);
      this._analyticsQueue.push(e);
    }
    get _analyticsQueue() {
      return window._hsq;
    }
    static getPageId() {
      const e = window.hsVars;
      return e && e.analytics_page_id
        ? e.analytics_page_id
        : e && e.page_id
          ? e.page_id
          : null;
    }
    static getLanguage() {
      const e = window.hsVars;
      return e && e.language ? e.language : null;
    }
  }
  var x = new U();
  const k = (...e) => {
      o("[AnalyticsProxyController]", ...e);
    },
    L = ["trackFormView", "trackFormVisible", "trackFormInteraction"];
  class q {
    constructor({ applicationController: e, analyticsStore: t }) {
      this.viewQueue = new Map();
      this.applicationController = e;
      this.analyticsStore = t;
      this.listenForAnalyticsUpdate();
      this.listenForProxyMessage();
    }
    listenForAnalyticsUpdate() {
      this.analyticsStore.subscribe((e, t) => {
        !t.isLoaded &&
          e.isLoaded &&
          u.broadcastAll({ type: a.RECEIVED_ANALYTICS, payload: e });
      });
    }
    flushViewQueue(e) {
      const t = this.viewQueue.get(e) || [];
      for (const e of t) this.analyticsStore.track(e);
      this.viewQueue.delete(e);
    }
    handleFormView(e, t) {
      const s = this.applicationController.viewedStore;
      if (s && s.hasBeenViewed(e)) {
        this.analyticsStore.track(t);
        return;
      }
      const n = this.viewQueue.get(e) || [];
      k("Adding form view to analytics queue", { id: e, analytics: t });
      this.viewQueue.set(e, [...n, t]);
    }
    listenForProxyMessage() {
      u.registerHandlers({
        [a.PROXY_ANALYTICS]: ({ analytics: e, id: t }) => {
          q.isFormView(e)
            ? this.handleFormView(t, e)
            : this.analyticsStore.track(e);
        },
      });
    }
    static isFormView(e) {
      const [t] = e;
      return L.includes(t);
    }
  }
  class j {
    constructor({ applicationController: e }) {
      this.applicationController = e;
      this.listenForNavigation();
    }
    listenForNavigation() {
      u.registerHandlers({
        [a.NAVIGATE_PAGE]: ({ url: e, openNewTab: t, id: s }) => {
          const n = this.applicationController.getNavigationUrl(
            { url: e, openNewTab: t },
            s,
          );
          if (t) return;
          F(
            n,
            this.applicationController.getShouldOpenNewTab(
              { url: e, openNewTab: t },
              s,
            ),
          );
        },
      });
    }
  }
  class G {
    constructor() {
      this.extractedStyles = { rules: {}, keyframes: {} };
      this.crossOriginStyleSheets = new Set();
    }
    extractStyles() {
      const e = { rules: {}, keyframes: {} };
      for (const t of document.styleSheets)
        if (!this.crossOriginStyleSheets.has(t))
          try {
            const s = t.cssRules || t.rules;
            for (const t of s)
              t instanceof CSSStyleRule
                ? (e.rules[t.selectorText] = this.extractProperties(t.style))
                : t instanceof CSSKeyframesRule &&
                  (e.keyframes[t.name] = this.extractKeyframes(t));
          } catch (e) {
            this.crossOriginStyleSheets.add(t);
          }
      this.extractedStyles = e;
    }
    extractProperties(e) {
      const t = {};
      for (const s of Array.from(e)) t[s] = e.getPropertyValue(s);
      return t;
    }
    extractKeyframes(e) {
      const t = [];
      for (const s of e.cssRules) {
        if (!(s instanceof CSSKeyframeRule)) continue;
        const e = this.extractProperties(s.style);
        t.push({ keyText: s.keyText, style: e });
      }
      return t;
    }
  }
  class $ {
    constructor() {
      this.analyticsStore = x;
      this.analyticsProxyController = new q({
        analyticsStore: this.analyticsStore,
        applicationController: this,
      });
      this.navigationProxyController = new j({ applicationController: this });
      this.styleExtractorController = new G();
    }
    getNavigationUrl(e, t) {
      return e.url;
    }
    getShouldOpenNewTab(e, t) {
      return e.openNewTab;
    }
  }
  class z {
    constructor() {
      this.handleIntersection = (e) => {
        e.forEach((e) => {
          if (e.isIntersecting) {
            const t = e.target;
            this.onElementAppear(t);
            this.observedElements.delete(t);
            this.observer.unobserve(t);
          }
        });
      };
      this.observer = new IntersectionObserver(this.handleIntersection, {
        threshold: 0.5,
      });
      this.observedElements = new Map();
    }
    onElementAppear(e) {
      const t = this.observedElements.get(e);
      t && t(e);
    }
    observe(e, t) {
      if (
        (() => {
          const t = e.getBoundingClientRect(),
            s = window.innerHeight;
          return t.bottom >= 0 && t.top < s;
        })()
      )
        t(e);
      else if (!this.observedElements.has(e)) {
        this.observedElements.set(e, t);
        this.observer.observe(e);
      }
    }
    unobserve(e) {
      if (this.observedElements.has(e)) {
        this.observedElements.delete(e);
        this.observer.unobserve(e);
      }
    }
  }
  function B() {
    return new z();
  }
  function Y(e, t) {
    const s = new Set(e.keys()),
      n = new Set(t.keys());
    return new Set([...n].filter((e) => !s.has(e)));
  }
  function Q(e, t) {
    const s = new Map(e);
    for (const [e, n] of t) s.set(e, n);
    return s;
  }
  const X = "hs-form-frame",
    W = "data-env",
    K = "data-form-id",
    J = "data-portal-id",
    Z = "data-instance-id",
    ee = "data-region",
    te = "data-test-id",
    se = "embedded-form-",
    ne = "title";
  var ie = () => Array.from(document.getElementsByClassName(X));
  const ae = "na1",
    re = "prod";
  var oe = () =>
    "randomUUID" in crypto
      ? crypto.randomUUID()
      : ([1e7] + -1e3 + -4e3 + 8e3 + -1e11).replace(/[018]/g, (e) =>
          (
            e ^
            (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (e / 4)))
          ).toString(16),
        );
  const ce = (e, t) => e.getAttribute(t) || "";
  var de = (e) => ({
    formId: ce(e, K),
    portalId: Number(ce(e, J)),
    region: ce(e, ee) || ae,
    env: ce(e, W) || re,
    instanceId: ce(e, Z) || oe(),
  });
  const le = /^[{]?[0-9a-fA-F]{8}-?([0-9a-fA-F]{4}-?){3}[0-9a-fA-F]{12}[}]?$/,
    he = ["qa", "prod"];
  var ue = (e) => {
    const { portalId: t, formId: s, env: n, instanceId: i } = e;
    return !(t < 1) && !!le.test(s) && !!he.includes(n) && !!i;
  };
  function me(e, t = ie()) {
    const s = new Map(),
      n = new Map();
    t.forEach((t) => {
      if (e.embedContextsMap.has(t)) return;
      const i = de(t);
      if (!ue(i)) {
        console.error(`${i} has missing or invalid data attributes.`);
        return;
      }
      const { formId: a } = i;
      s.set(a, [...(s.get(a) || []), t]);
      n.set(t, i);
    });
    return { formContainerElementsMap: s, embedContextsMap: n };
  }
  function pe(e, t, s = 5) {
    if (!(s < 0) && e.nodeType === Node.ELEMENT_NODE) {
      const n = e;
      n.classList.contains(X) && t.push(n);
      n.childNodes.forEach((e) => {
        pe(e, t, s - 1);
      });
    }
  }
  function fe(e) {
    const t = new MutationObserver((t) => {
      const s = [];
      for (const e of t)
        if ("childList" === e.type) for (const t of e.addedNodes) pe(t, s);
      s.length && e(s);
    });
    t.observe(document.body, { childList: !0, subtree: !0 });
    return () => {
      t.disconnect();
    };
  }
  const Ee = u;
  var _e = (e) => {
    const t = new Image();
    t.alt = "";
    t.src = e;
  };
  const ge = "https://forms{{region}}.hsforms{{env}}.com/embed/v3",
    be = ({ env: e, region: t }) => {
      const s = t ? `-${t}` : "",
        n = "qa" === e ? "qa" : "";
      return ge.replace("{{region}}", s).replace("{{env}}", n);
    };
  var Se = (e = "", t = 1, s = { env: "", region: "" }) => {
    _e(`${be(s)}/counters.gif?key=${e}&count=${t}`);
  };
  var Ie = { FORM_FRAME_LOAD_SUCCESS: "form-frame-load-success" };
  const ve = "?";
  function ye() {
    return "undefined" == typeof document || null == document.location
      ? ""
      : document.location.href;
  }
  function Ce() {
    return "undefined" == typeof document || null == document.location
      ? ""
      : document.location.origin
        ? document.location.origin
        : `${document.location.protocol}//${document.location.hostname}${document.location.port ? `:${document.location.port}` : ""}`;
  }
  function Ae(e) {
    if (void 0 === e.stack || !e.stack) return null;
    const t =
        /^\s*at (?:(.*?) ?\()?((?:file|https?|blob|chrome-extension|native|eval|webpack|<anonymous>|[a-z]:|\/).*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i,
      s =
        /^\s*at (?:((?:\[object object\])?.+) )?\(?((?:file|ms-appx(?:-web)|https?|webpack|blob):.*?):(\d+)(?::(\d+))?\)?\s*$/i,
      n =
        /^\s*(.*?)(?:\((.*?)\))?(?:^|@)((?:file|https?|blob|chrome|webpack|resource|moz-extension).*?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js))(?::(\d+))?(?::(\d+))?\s*$/i,
      i = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i,
      a = /\((\S*)(?::(\d+))(?::(\d+))\)/,
      r = e.stack.split("\n"),
      o = [];
    let c, d, l;
    for (let h = 0, u = r.length; h < u; ++h) {
      if ((d = t.exec(r[h]))) {
        const e = d[2] && 0 === d[2].indexOf("native");
        if (d[2] && 0 === d[2].indexOf("eval") && (c = a.exec(d[2]))) {
          d[2] = c[1];
          d[3] = c[2];
          d[4] = c[3];
        }
        l = {
          filename: e ? null : d[2],
          function: d[1] || ve,
          args: e ? [d[2]] : [],
          lineno: d[3] ? +d[3] : null,
          colno: d[4] ? +d[4] : null,
        };
      } else if ((d = s.exec(r[h])))
        l = {
          filename: d[2],
          function: d[1] || ve,
          args: [],
          lineno: +d[3],
          colno: d[4] ? +d[4] : null,
        };
      else {
        if (!(d = n.exec(r[h]))) continue;
        if (d[3] && d[3].indexOf(" > eval") > -1 && (c = i.exec(d[3]))) {
          d[3] = c[1];
          d[4] = c[2];
          d[5] = null;
        } else
          0 !== h ||
            d[5] ||
            void 0 === e.columnNumber ||
            (o[0].column = e.columnNumber + 1);
        l = {
          filename: d[3],
          function: d[1] || ve,
          args: d[2] ? d[2].split(",") : [],
          lineno: d[4] ? +d[4] : null,
          colno: d[5] ? +d[5] : null,
        };
      }
      !l.function && l.line && (l.function = ve);
      if (l.filename && "blob:" === l.filename.substr(0, 5)) {
        const e = new XMLHttpRequest();
        e.open("GET", l.filename, !1);
        e.send(null);
        if (200 === e.status) {
          let t = e.responseText || "";
          t = t.slice(-300);
          const s = t.match(/\/\/# sourceMappingURL=(.*)$/);
          if (s) {
            let e = s[1];
            "~" === e.charAt(0) && (e = Ce() + e.slice(1));
            l.url = e.slice(0, -4);
          }
        }
      }
      o.push(l);
    }
    return o.length
      ? { name: e.name, message: e.message, url: ye(), stack: o }
      : null;
  }
  function we(e, t, s) {
    const n = { filename: t, lineno: s };
    if (n.filename && n.lineno) {
      e.incomplete = !1;
      n.function || (n.function = ve);
      if (e.stack.length > 0 && e.stack[0].filename === n.filename) {
        if (e.stack[0].lineno === n.lineno) return !1;
        if (!e.stack[0].lineno && e.stack[0].function === n.function) {
          e.stack[0].lineno = n.lineno;
          return !1;
        }
      }
      e.stack.unshift(n);
      e.partial = !0;
      return !0;
    }
    e.incomplete = !0;
    return !1;
  }
  function Te(e, t) {
    const s =
        /function\s+([_$a-zA-Z\xA0-\uFFFF][_$a-zA-Z0-9\xA0-\uFFFF]*)?\s*\(/i,
      n = [],
      i = {};
    let a,
      r,
      o = !1;
    for (let e = Te.caller; e && !o; e = e.caller)
      if (e !== Fe) {
        r = { filename: null, function: ve, lineno: null, colno: null };
        e.name
          ? (r.function = e.name)
          : (a = s.exec(e.toString())) && (r.function = a[1]);
        if (void 0 === r.function)
          try {
            r.function = a.input.substring(0, a.input.indexOf("{"));
          } catch (e) {}
        i[`${e}`] ? (o = !0) : (i[`${e}`] = !0);
        n.push(r);
      }
    t && n.splice(0, t);
    const c = { name: e.name, message: e.message, filename: ye(), stack: n };
    we(
      c,
      e.sourceURL || e.fileName,
      e.line || e.lineNumber,
      e.message || e.description,
    );
    return c;
  }
  function Fe(e, t) {
    if ("string" == typeof e)
      return { name: "Error", message: e, filename: ye() };
    let s = null;
    t = null == t ? 0 : +t;
    try {
      s = Ae(e);
      if (s) return s;
    } catch (e) {}
    try {
      s = Te(e, t + 1);
      if (s) return s;
    } catch (e) {}
    return { name: e.name, message: e.message, filename: ye() };
  }
  const Re = [
      /timeout exceeded/,
      /Request aborted/,
      /Network Error/,
      /Failed to execute 'send' on 'XMLHttpRequest'/,
      /Unexpected end of JSON input/,
      /Unexpected token/,
      /IP_ADDRESS_IS_PROBABLY_A_BOT/,
      /SUBMISSION_PERIOD_ENDED/,
      /RATE_LIMIT_EXCEEDED/,
      /Failed to execute 'removeChild' on 'Node'/,
      /Failed to execute 'insertBefore' on 'Node'/,
    ],
    Ne = [/\/OtAutoBlock\.js/, /\/mootools\.js/],
    Oe = [
      /ui-forms-embed-components/,
      /embed-default-modules/,
      /\/?forms\/embed\/(frame(-v2)?|\d+)\.js/,
      /web-interactives-embed-framework/,
    ],
    Me = (e, t) => {
      const s = Fe(e),
        n = s.stack ? s.stack[0].filename : s.filename;
      return (
        Oe.some((t) => t.test(e.stack || "")) &&
        (!!t || Oe.some((e) => e.test(n)))
      );
    };
  var De = (e, t = !1) => {
    if (!e) return !1;
    const { message: s = "", stack: n = "" } = e;
    return Boolean(
      s &&
      n &&
      Me(e, t) &&
      !Re.find((e) => e.test(s)) &&
      !Ne.find((e) => e.test(n)),
    );
  };
  const Ve = { APP: "app", APP_API: "app-api" };
  function Pe(e, t) {
    const s = t && t.hubletOverride ? t.hubletOverride : e,
      n = t && !0 === t.hubletizeNa1;
    return s !== ae || n ? `-${s}` : "";
  }
  function He(e, t, s) {
    if (s && s.hubletPostfixLocation && "domain" === s.hubletPostfixLocation)
      return t;
    t === Ve.APP_API && (t = Ve.APP);
    return `${t}${Pe(e, s)}`;
  }
  function Ue(e, t, s) {
    return `${ke(s)}${xe(t, s)}${Le(e, s)}`;
  }
  function xe(e, t) {
    return "qa" === (t && t.envOverride ? t.envOverride : e) ? "qa" : "";
  }
  function ke(e) {
    return e && e.domainOverride ? e.domainOverride : "hubspot";
  }
  function Le(e, t) {
    return t && t.hubletPostfixLocation && "domain" === t.hubletPostfixLocation
      ? Pe(e, t)
      : "";
  }
  function qe(e) {
    return e && e.tldOverride ? e.tldOverride : "com";
  }
  function je(e) {
    return e === Ve.APP_API ? "/api" : "";
  }
  function Ge(e, t, s, n) {
    return `https://${He(t, e, n)}.${Ue(t, s, n)}.${qe(n)}${je(e)}`;
  }
  const $e = "eeb5bcc1447eba257645d7fee6f7a0b7";
  var ze = ({ hublet: e = ae, env: t }) =>
    `${Ge("exceptions", e, "qa" === t ? "qa" : "prod", { tldOverride: "com" })}/v2/api/store?sentry_key=${$e}`;
  var Be = () =>
    "randomUUID" in crypto
      ? crypto.randomUUID()
      : ([1e7] + -1e3 + -4e3 + 8e3 + -1e11).replace(/[018]/g, (e) =>
          (
            e ^
            (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (e / 4)))
          ).toString(16),
        );
  var Ye = (
    e,
    t,
    {
      env: s = "prod",
      url: n = "",
      query: i = "",
      version: a = "",
      hublet: r = "",
      tags: o = {},
      user: c = {},
      extra: d = {},
    },
  ) => {
    const l = Date.now() / 1e3,
      h = Fe(t);
    return {
      environment: s,
      tags: Object.assign({ region: r }, o),
      logger: "javascript",
      platform: "javascript",
      request: {
        headers: { "User-Agent": navigator.userAgent },
        url: n || window.location.href,
        queryString: i.replace(/^\?/, ""),
      },
      event_id: Be().replace(/-/g, ""),
      transaction: h.stack ? h.stack[0].filename : h.filename,
      level: e,
      exception: {
        values: [
          {
            mechanism: { handled: !0, type: "generic" },
            type: h.name,
            value: h.message,
            stacktrace: { frames: h.stack ? h.stack.reverse() : [] },
          },
        ],
      },
      timestamp: l,
      version: a,
      user: c,
      extra: d,
    };
  };
  var Qe = (e = "", t, s = {}) => {
    const n = Ye(e, t, s);
    fetch(ze(s), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(n),
      keepalive: !0,
    });
  };
  var Xe = (e, t, s) => {
    const { env: n, hublet: i, formId: a, portalId: r, pageUrl: o } = e,
      { renderVersion: c, projectVersion: d, module: l } = t,
      { key: h, error: u, data: m } = s;
    if (De(u)) {
      const e = new URL(o);
      Qe("error", u, {
        type: "Error",
        env: n,
        hublet: i,
        url: e.href,
        query: e.search,
        tags: { renderVersion: c, projectVersion: d, key: h, module: l },
        extra: { key: h, data: JSON.stringify(m), formId: a, portalId: r },
      });
    }
  };
  var We = ({
    formId: e = "",
    portalId: t = "",
    hublet: s = ae,
    isQa: n = !1,
    key: i,
    error: a = "",
    data: r = {},
  }) => {
    const o = {
        formId: e,
        portalId: t,
        env: n ? "qa" : "prod",
        hublet: s,
        pageUrl: window.location.href,
      },
      c = {
        renderVersion: "1",
        projectVersion: "1",
        module: "ui-forms-embed-components-frame-parent",
      },
      d = {
        key: i,
        error: a,
        data: r.response && r.response.data ? r.response.data : r,
      };
    Xe(o, c, d);
  };
  const Ke = "FORM_FRAME_RENDER_ERROR";
  let Je = !1;
  var Ze = ({ defaultUrl: e, region: t, isQa: s }) => {
    let n = null;
    if (
      !(
        "true" ===
        new URLSearchParams(window.location.search).get(
          "_hsFormsRenderingTestTool_Do_Not_Use",
        )
      ) ||
      Je
    )
      return;
    const i = new URL(e),
      a = new URL(
        Ge("tools", t && t.length > 0 ? t : ae, s ? "qa" : "prod", {
          domainOverride: "hubteam",
        }),
      ),
      r = (e) => {
        var t;
        if (
          "hs-forms:render-tool:iframe-ready" ===
            (null === (t = e.data) || void 0 === t ? void 0 : t.type) &&
          e.origin === i.origin
        ) {
          n = e.source;
          window.parent.postMessage(
            { type: "hs-forms:render-tool:iframe-ready" },
            a.href,
          );
        }
      },
      o = (e) => {
        var t;
        if (
          "hs-forms:render-tool:init-log-channel" ===
            (null === (t = e.data) || void 0 === t ? void 0 : t.type) &&
          e.ports[0] &&
          e.origin === a.origin
        ) {
          const t = new MessageChannel();
          t.port1.onmessage = (t) => {
            e.ports[0].postMessage(t.data);
          };
          if (!n) return;
          n.postMessage(
            { type: "hs-forms:render-tool:init-log-channel" },
            { targetOrigin: i.origin, transfer: [t.port2] },
          );
          Je = !0;
          window.removeEventListener("message", r);
          window.removeEventListener("message", o);
        }
      };
    window.addEventListener("message", r);
    window.addEventListener("message", o);
  };
  class et {
    constructor({ embedContext: e, container: t, iframeSrc: s }) {
      this.handleLoad = () => {
        this.frameComponent.setStyle({ visibility: "" });
      };
      this.sendEmbedContextWithInstanceId = (e) => {
        this.frameComponent.iframeCommunicator.sendMessage({
          type: a.SEND_EMBED_CONTEXT,
          payload: e,
        });
      };
      this.listenForV4FormReadyEvent = () => {
        Ee.registerHandlers({
          [a.V4_FORM_READY]: ({ instanceId: e }) => {
            this.sendEmbedContextWithInstanceId(
              Object.assign({}, this.embedContext, { instanceId: e }),
            );
          },
        });
      };
      this.listenForLoad();
      this.container = t;
      this.initContainer();
      this.embedContext = e;
      this.frameComponent = w({
        iframeSrc: s,
        container: t,
        id: e.formId,
        onFrameReady: this.resolveFrameload,
        resizeHeight: !0,
        extraAttributes: {
          [te]: `${se}${e.formId}`,
          [ne]: "Form",
          scrolling: "no",
        },
      });
      this.listenForV4FormReadyEvent();
    }
    initContainer() {
      this.container.style.height = "0";
      this.container.replaceChildren();
    }
    listenForLoad() {
      const e = new Promise((e) => {
        this.resolveFrameload = e;
      });
      Promise.all([e])
        .then(() => {
          this.handleLoad();
          Se(Ie.FORM_FRAME_LOAD_SUCCESS, 1, {
            env: this.embedContext.env,
            region: this.embedContext.region,
          });
        })
        .catch((e) => {
          We({
            formId: this.embedContext.formId,
            portalId: this.embedContext.portalId.toString(),
            hublet: this.embedContext.region,
            isQa: "qa" === this.embedContext.env,
            key: Ke,
            error: e instanceof Error ? e : new Error(String(e)),
          });
        });
    }
  }
  function tt({ embedContext: e, container: t, iframeSrc: s }) {
    Ze({ defaultUrl: s, isQa: "qa" === e.env, region: e.region });
    return new et({ embedContext: e, container: t, iframeSrc: s });
  }
  var st = ({
    subDomainPrefix: e,
    hublet: t,
    isQa: s,
    pathname: n = "",
    pathValues: i = {},
    domainOverride: a,
    tldOverride: r,
    query: o,
  }) => {
    const c = Object.keys(i).reduce(
        (e, t) => e.replace(RegExp(`{{${t}}}`, "g"), i[t]),
        n,
      ),
      d = Ge(e, t || ae, s ? "qa" : "prod", {
        domainOverride: a,
        tldOverride: r,
      }),
      l = new URL(c, d);
    if (o) for (const [e, t] of Object.entries(o)) l.searchParams.append(e, t);
    return l.href;
  };
  function nt({
    portalId: e,
    formId: t,
    region: s,
    env: n,
    hutk: i,
    instanceId: a,
  }) {
    const r = Object.assign(
        {},
        Object.fromEntries(new URLSearchParams(window.location.search)),
      ),
      o = "true" === r.isLocal,
      c = {
        hublet: o ? ae : s,
        isQa: !o && "qa" === n,
        subDomainPrefix: o ? "local" : "js",
        domainOverride: o ? "hsappstatic" : "hsforms",
        tldOverride: "net",
      },
      d = Object.assign(
        {
          _hsPortalId: `${e || ""}`,
          _hsFormId: t || "",
          _hsIsQa: `${"qa" === n}`,
          _hsHublet: s || ae,
          _hsDisableScriptloader: "true",
          _hsDisableRedirect: "true",
          _hsInstanceId: a,
        },
        i && { _hsUtk: i },
        r,
      );
    return st(
      Object.assign({}, c, {
        pathname: o
          ? "ui-forms-embed-components-app/static/html/frame.html"
          : "ui-forms-embed-components-app/frame.html",
        query: d,
      }),
    );
  }
  const it = () => {
    var e, t;
    return {
      pageUrl: window.location.href,
      pageTitle: window.document.title,
      referrer: window.document.referrer,
      pageId:
        (null === (e = window.hsVars) || void 0 === e
          ? void 0
          : e.analytics_page_id) ||
        (null === (t = window.hsVars) || void 0 === t ? void 0 : t.page_id) ||
        null,
      isHubSpotCmsGeneratedPage: Boolean(
        window.document.querySelector(
          'meta[name="generator"][content="HubSpot"]',
        ),
      ),
    };
  };
  class at {
    constructor({ embeddedContainers: e, handleView: t, analyticsStore: s }) {
      this.elementObserver = B();
      this.embedComponents = new Map();
      this.embeddedContainers = e;
      this.handleView = t;
      this.analyticsStore = s;
      this.listenForEmbeddedContainers();
    }
    listenForEmbeddedContainers() {
      this.embeddedContainers.subscribe((e, t) => {
        const s = Y(t.embedContextsMap, e.embedContextsMap);
        this.createViews([...s]);
        this.listenForElementViews([...s]);
      });
    }
    listenForElementViews(e) {
      for (const t of e) {
        const e = this.embeddedContainers.embedContextsMap.get(t);
        if (!e) return;
        this.elementObserver.observe(t, () => this.handleView(e.formId));
      }
    }
    createViews(e) {
      for (const t of e) {
        const e = this.embeddedContainers.embedContextsMap.get(t);
        if (!e) continue;
        if (this.embedComponents.has(t)) continue;
        const s = this.analyticsStore.analytics.hutk,
          n = tt({
            embedContext: Object.assign({}, e, it(), s && { hutk: s }),
            container: t,
            iframeSrc: nt({
              hutk: s,
              instanceId: e.instanceId,
              portalId: e.portalId,
              formId: e.formId,
              region: e.region,
              env: e.env,
            }),
          });
        this.embedComponents.set(t, n);
      }
    }
  }
  function rt(e) {
    return new at(e);
  }
  class ot {
    constructor() {
      const e = {
        formContainerElementsMap: new Map(),
        embedContextsMap: new Map(),
      };
      this.store = new T(e);
    }
    subscribe(e) {
      return this.store.subscribe(e);
    }
    get formContainerElements() {
      return this.store.state.formContainerElementsMap;
    }
    get embedContextsMap() {
      return this.store.state.embedContextsMap;
    }
    getFrameContainerFromInstanceId(e) {
      const t = Array.from(this.store.state.embedContextsMap.entries()).find(
        ([, t]) => t.instanceId === e,
      );
      if (!t) throw new Error(`No embed context found for instanceId: ${e}`);
      return t[0];
    }
    addElements(e) {
      this.store.setState((t) => ({
        formContainerElementsMap: Q(
          t.formContainerElementsMap,
          e.formContainerElementsMap,
        ),
        embedContextsMap: Q(t.embedContextsMap, e.embedContextsMap),
      }));
    }
  }
  class ct {
    constructor() {
      this.markAsViewed = (e) => {
        this.store.setState((t) =>
          Object.assign({}, t, { viewed: new Set([...t.viewed, e]) }),
        );
      };
      const e = { viewed: new Set() };
      this.store = new T(e);
    }
    subscribe(e) {
      this.store.subscribe(e);
    }
    hasBeenViewed(e) {
      return this.store.state.viewed.has(e);
    }
    get viewed() {
      return this.store.state.viewed;
    }
  }
  function dt() {
    return new ct();
  }
  const lt = window;
  class ht {
    constructor(e) {
      this.formData = e;
      this.attachToWindow();
    }
    init(e) {
      const { instanceId: t, formId: s } = e;
      this.createFormInstanceMethods(e);
      this.formData.setFormInstanceInfo({
        instanceId: t,
        formInfo: { formId: s },
      });
    }
    attachToWindow() {
      if (!Object.prototype.hasOwnProperty.call(lt, t)) {
        Object.defineProperty(lt, t, {
          value: {
            [n]: {
              _forms: new Map(),
              _setFormInstanceMethods({ instanceId: e, instanceMethods: t }) {
                const s = this[n],
                  i = s._forms.get(e);
                s._forms.set(e, Object.assign({}, i, { instanceMethods: t }));
              },
              _setFormGlobalVisibleEvent({ instanceId: e, eventDetails: t }) {
                const s = this[n],
                  i = s._forms.get(e);
                s._forms.set(
                  e,
                  Object.assign({}, i, {
                    globalVisibleEvent: { eventDetails: t },
                  }),
                );
              },
              _getFormInstanceMethodsByInstanceId(e) {
                var t;
                return null === (t = this[n]._forms.get(e)) || void 0 === t
                  ? void 0
                  : t.instanceMethods;
              },
            },
            getForms() {
              return Array.from(this[n]._forms.values())
                .map((e) => e.instanceMethods)
                .filter((e) => void 0 !== e);
            },
            getFormFromEvent({ detail: { instanceId: e } }) {
              return this[n]._getFormInstanceMethodsByInstanceId.call(this, e);
            },
          },
          writable: !1,
          configurable: !0,
        });
        lt[s] = lt[t];
      }
    }
    createFormInstanceMethods(e) {
      const { instanceId: t, formId: s } = e,
        { clientApi: n, __internalApi: i } = this.getFormInternalApi() || {};
      n &&
        i &&
        !i._getFormInstanceMethodsByInstanceId.call(n, t) &&
        i._setFormInstanceMethods.call(n, {
          instanceId: t,
          instanceMethods: {
            getFieldValue: (t) => this.getFieldValue(e, t),
            getFormId: () => s,
            getInstanceId: () => t,
            getRedirectUrl: () => this.formData.getRedirectUrl(t),
            getConversionId: () => this.formData.getConversionId(t),
            getFormFieldValues: () => this.getFormFieldValues(e),
            setFieldValue: (t, s) =>
              this.setFieldValue({
                baseFormInfo: e,
                propertyReference: t,
                value: s,
              }),
            setExtraSubmissionMetadata: (e) =>
              this.sendExtraSubmissionMetadata({
                formId: s,
                instanceId: t,
                metadata: e,
              }),
          },
        });
    }
    sendExtraSubmissionMetadata(e) {
      const { formId: t } = e;
      Ee.broadcast(t, {
        type: a.SEND_FORM_EXTRA_SUBMISSION_METADATA,
        payload: e,
      });
    }
    setFieldValue({ baseFormInfo: e, propertyReference: t, value: s }) {
      const { formId: n, instanceId: i } = e;
      Ee.broadcast(n, {
        type: a.SET_FIELD_VALUE,
        payload: { instanceId: i, propertyReference: t, value: s },
      });
    }
    async getFormFieldValues(e) {
      let t;
      const { formId: s } = e,
        n = new Promise((e) => {
          t = e;
        });
      this.listenForSendFormFieldValues(t);
      Ee.broadcast(s, { type: a.GET_FORM_FIELD_VALUES, payload: e });
      return await n.then((e) => e);
    }
    async getFieldValue(e, t) {
      let s;
      const { formId: n, instanceId: i } = e,
        r = new Promise((e) => {
          s = e;
        });
      this.listenForSendFieldValue(s);
      Ee.broadcast(n, {
        type: a.GET_FIELD_VALUE,
        payload: { instanceId: i, propertyReference: t },
      });
      return await r.then((e) => e);
    }
    listenForSendFormFieldValues(e) {
      Ee.registerHandlers({
        [a.SEND_FORM_FIELD_VALUES]: ({ formFieldValues: t }) => {
          null == e || e(t);
        },
      });
    }
    listenForSendFieldValue(e) {
      Ee.registerHandlers({
        [a.SEND_FIELD_VALUE]: ({ fieldValue: t }) => {
          null == e || e(t);
        },
      });
    }
    getFormInternalApi() {
      const e = lt[t];
      if (e && e[n]) return { clientApi: e, __internalApi: e[n] };
    }
  }
  function ut(e) {
    return new ht(e);
  }
  const mt = (e) => {
      if (!e) return;
      e.getBoundingClientRect().top < 0 &&
        e.scrollIntoView({ behavior: "smooth", block: "start" });
    },
    pt = {
      ON_FORM_READY: "hs-form-event:on-ready",
      ON_FORM_SUBMISSION_SUCCESS: "hs-form-event:on-submission:success",
      ON_FORM_SUBMISSION_FAILED: "hs-form-event:on-submission:failed",
      ON_FORM_INTERACTION_NAVIGATE: "hs-form-event:on-interaction:navigate",
      ON_FORM_INTERACTION_NAVIGATE_NEXT:
        "hs-form-event:on-interaction:navigate:next",
      ON_FORM_INTERACTION_NAVIGATE_PREVIOUS:
        "hs-form-event:on-interaction:navigate:previous",
    };
  class ft {
    constructor(e, t) {
      this.formData = e;
      this.embeddedContainers = t;
    }
    init({ initialiseThirdPartyApi: e }) {
      this.listenForFormReadyEvent({ initialiseThirdPartyApi: e });
      this.listenForFormNavigationEvent();
      this.listenForFormNavigationNextEvent();
      this.listenForFormNavigationPreviousEvent();
      this.listenForSubmissionSuccessEvent();
      this.listenForSubmissionFailedEvent();
    }
    listenForFormReadyEvent({ initialiseThirdPartyApi: e }) {
      Ee.registerHandlers({
        [a.V4_FORM_READY]: (t) => {
          e(t);
          this.triggerGlobalEvent(
            Object.assign({}, t, { type: pt.ON_FORM_READY }),
          );
        },
      });
    }
    listenForSubmissionSuccessEvent() {
      Ee.registerHandlers({
        [a.SEND_FORM_SUBMISSION_SUCCESS]: ({ formId: e, instanceId: t }) => {
          this.triggerGlobalEvent({
            type: pt.ON_FORM_SUBMISSION_SUCCESS,
            instanceId: t,
            formId: e,
          });
        },
      });
    }
    listenForFormNavigationEvent() {
      Ee.registerHandlers({
        [a.SEND_FORM_INTERACTION_NAVIGATE]: (e) => {
          this.triggerGlobalEvent(
            Object.assign({}, e, { type: pt.ON_FORM_INTERACTION_NAVIGATE }),
          );
        },
      });
    }
    listenForFormNavigationNextEvent() {
      Ee.registerHandlers({
        [a.SEND_FORM_INTERACTION_NAVIGATE_NEXT]: (e) => {
          const t = this.embeddedContainers.getFrameContainerFromInstanceId(
            e.instanceId,
          );
          t && mt(t);
          this.triggerGlobalEvent(
            Object.assign({}, e, {
              type: pt.ON_FORM_INTERACTION_NAVIGATE_NEXT,
            }),
          );
        },
      });
    }
    listenForFormNavigationPreviousEvent() {
      Ee.registerHandlers({
        [a.SEND_FORM_INTERACTION_NAVIGATE_PREVIOUS]: (e) => {
          this.triggerGlobalEvent(
            Object.assign({}, e, {
              type: pt.ON_FORM_INTERACTION_NAVIGATE_PREVIOUS,
            }),
          );
        },
      });
    }
    listenForSubmissionFailedEvent() {
      Ee.registerHandlers({
        [a.SEND_FORM_SUBMISSION_FAILED]: ({ formId: e, instanceId: t }) => {
          this.triggerGlobalEvent({
            type: pt.ON_FORM_SUBMISSION_FAILED,
            instanceId: t,
            formId: e,
          });
        },
      });
    }
    triggerGlobalEvent({ type: e, instanceId: t, formId: s }) {
      if (
        document &&
        void 0 !== typeof window &&
        window &&
        window.CustomEvent
      ) {
        const n =
            this.embeddedContainers.getFrameContainerFromInstanceId(t) ||
            document,
          i = new CustomEvent(e, {
            bubbles: !0,
            cancelable: !0,
            detail: { formId: s, instanceId: t },
          });
        n.dispatchEvent(i);
      }
    }
  }
  function Et(e, t) {
    return new ft(e, t);
  }
  class _t {
    constructor() {
      this.formDataMap = new Map();
    }
    setFormInstanceInfo({ instanceId: e, formInfo: t }) {
      const s = this.formDataMap.get(e) || {};
      this.formDataMap.set(e, Object.assign({}, s, t));
    }
    getRedirectUrl(e) {
      var t;
      return (
        (null === (t = this.formDataMap.get(e)) || void 0 === t
          ? void 0
          : t.redirectUrl) || ""
      );
    }
    getConversionId(e) {
      var t;
      return (
        (null === (t = this.formDataMap.get(e)) || void 0 === t
          ? void 0
          : t.conversionId) || ""
      );
    }
  }
  var gt = _t;
  const bt = "__INTERNAL_PERFORMANCE__",
    St = (e, t = 2) =>
      Number.isFinite(e) ? Math.round(e * 10 ** t) / 10 ** t : e,
    It = (e) => {
      if (
        !window.performance ||
        "function" != typeof window.performance.getEntriesByType
      )
        return {};
      const t = performance.getEntriesByType("navigation");
      if (!t || 0 === t.length) return {};
      const s = t[0],
        n = {
          parentDomInteractive: St(s.domInteractive),
          parentPageLoad: St(s.loadEventEnd),
        },
        i = performance
          .getEntriesByType("resource")
          .find(
            (t) =>
              "iframe" === t.initiatorType &&
              t.name.includes(`_hsInstanceId=${e.instanceId}`) &&
              t.name.includes(`_hsFormId=${e.formId}`),
          );
      i && (n.parentFrameMounted = St(i.startTime));
      return n;
    },
    vt = "https://google.com/recaptcha/enterprise.js",
    yt = "https://recaptcha.net/recaptcha/enterprise.js",
    Ct = () => {
      var e;
      return (
        (window &&
          window.grecaptcha &&
          (null === (e = window.grecaptcha) || void 0 === e
            ? void 0
            : e.enterprise)) ||
        void 0
      );
    },
    At = ({ src: e, onError: t }) => {
      const s = window.document.createElement("script");
      s.async = !0;
      s.defer = !0;
      s.type = "text/javascript";
      s.onerror = t;
      s.src = e;
      return s;
    },
    wt = ({ callbackId: e, locale: t }) => {
      const s = At({
        src: `${vt}?&onload=${e}&render=explicit&hl=${t}`,
        onError: () => {
          const s = At({
            src: `${yt}?&onload=${e}&render=explicit&hl=${t}`,
            onError: (e) => {
              throw e;
            },
          });
          window.document.head.appendChild(s);
        },
      });
      window.document.head.appendChild(s);
    },
    Tt = "hs-forms-embed-frame-recaptcha";
  class Ft {
    constructor() {
      this.handleRenderRecaptcha = ({
        callbackId: e,
        UUID: t,
        sitekey: s,
        inherit: n,
        size: i,
        badge: a,
        locale: r,
      }) => {
        const o = () => {
          const e = this.createRecaptchaTarget(t),
            r = { target: e },
            o = Ct();
          if (o && e && r) {
            const c = o.render(
              e,
              {
                sitekey: s,
                callback: (e) => {
                  this.onSuccess(e, t);
                },
                "expired-callback": () => {
                  this.onExpired(t);
                },
                "error-callback": () => {
                  this.onError();
                },
                size: i,
                badge: a,
              },
              n,
            );
            this.recaptchas.set(t, Object.assign({}, r, { widgetId: c }));
          }
        };
        if (this.recaptchaLoaded) o();
        else if (this.recaptchaLoadQueued) this.renderQueue.push(o);
        else {
          this.recaptchaLoadQueued = !0;
          this.renderQueue.push(o);
          window[e] = () => {
            this.recaptchaLoaded = !0;
            this.renderQueue.forEach((e) => e());
            this.renderQueue = [];
          };
          wt({ callbackId: e, locale: r });
        }
      };
      this.createRecaptchaTarget = (e) => {
        const t = `${Tt}_${e}`,
          s = document.createElement("div");
        s.setAttribute("id", t);
        s.style.setProperty("display", "none");
        s.style.setProperty("width", "0px");
        s.style.setProperty("height", "0px");
        document.body.appendChild(s);
        return s;
      };
      this.handleExecuteRecaptcha = (e) => {
        const t = this.recaptchas.get(e);
        if (t) {
          const e = t.widgetId,
            s = Ct();
          s && void 0 !== e && s.execute(e);
        }
      };
      this.handleResetRecaptcha = (e) => {
        const t = this.recaptchas.get(e);
        if (t) {
          const e = t.widgetId,
            s = Ct();
          s && void 0 !== e && s.reset(e);
        }
      };
      this.onSuccess = (e, t) => {
        u.broadcastAll({
          type: a.V4_RECAPTCHA_SUCCESS,
          payload: { UUID: t, token: e },
        });
      };
      this.onExpired = (e) => {
        u.broadcastAll({ type: a.V4_RECAPTCHA_EXPIRED, payload: { UUID: e } });
      };
      this.onError = () => {
        u.broadcastAll({ type: a.V4_RECAPTCHA_ERROR });
      };
      this.recaptchas = new Map();
      this.recaptchaLoadQueued = !1;
      this.recaptchaLoaded = !1;
      this.renderQueue = [];
      this.listenForRecaptchaEvents();
    }
    listenForRecaptchaEvents() {
      u.registerHandlers({
        [a.V4_RECAPTCHA_RENDER]: (e) => {
          this.handleRenderRecaptcha(e);
        },
        [a.V4_RECAPTCHA_EXECUTE]: (e) => {
          this.handleExecuteRecaptcha(e.UUID);
        },
        [a.V4_RECAPTCHA_RESET]: (e) => {
          this.handleResetRecaptcha(e.UUID);
        },
      });
    }
  }
  function Rt() {
    return new Ft();
  }
  class Nt extends $ {
    constructor({ embededContainers: e }) {
      super();
      this.handleView = (e) => {
        this.viewedStore.markAsViewed(e);
        this.analyticsProxyController.flushViewQueue(e);
      };
      this.initialiseThirdPartyApi = (e) => {
        this.thirdPartyApiController.init(e);
      };
      this.embededContainers = e;
      this.viewedStore = dt();
      this.embeddedFormsController = rt({
        embeddedContainers: this.embededContainers,
        handleView: this.handleView,
        analyticsStore: this.analyticsStore,
      });
      this.formData = new gt();
      this.thirdPartyApiController = ut(this.formData);
      this.globalEventController = Et(this.formData, this.embededContainers);
      this.recaptchaController = Rt();
    }
    init() {
      this.globalEventController.init({
        initialiseThirdPartyApi: this.initialiseThirdPartyApi,
      });
      this.listenForFormReadyEvent();
      this.listenForSubmissionSuccessInfo();
      this.embededContainers.addElements(me(this.embededContainers));
      this.listenForAddedEmbeddedContainers();
    }
    listenForAddedEmbeddedContainers() {
      fe((e) => {
        const t = me(this.embededContainers, e);
        this.embededContainers.addElements(t);
      });
    }
    listenForFormReadyEvent() {
      Ee.registerHandlers({
        [a.V4_FORM_READY]: (e) => {
          const s = lt[t].getFormFromEvent({ detail: e }),
            n = It(e);
          null == s || s.setExtraSubmissionMetadata({ [bt]: n });
        },
      });
    }
    listenForSubmissionSuccessInfo() {
      Ee.registerHandlers({
        [a.SEND_FORM_SUBMISSION_SUCCESS_INFO]: ({
          instanceId: e,
          redirectUrl: t,
          conversionId: s,
        }) => {
          this.formData.setFormInstanceInfo({
            instanceId: e,
            formInfo: { redirectUrl: t, conversionId: s },
          });
        },
      });
    }
  }
  const Ot = new Nt({ embededContainers: new ot() });
  var Mt = Nt;
  const Dt = () => lt[e],
    Vt = () => "loading" === document.readyState,
    Pt = () => {
      lt[e] = {
        projectName: `${i.bender.project}`,
        app: `${i.bender.project}-${i.bender.depVersions[i.bender.project]}`,
        mountedAt: window.performance.now(),
        mountedBy: document.currentScript,
        instance: Mt,
        numAttemptedScriptInits: 1,
      };
    };
  (() => {
    const e = Dt();
    if (e) {
      1 === e.numAttemptedScriptInits &&
        document.currentScript &&
        console.warn(
          `The script ${document.currentScript.getAttribute("src")} only needs to be included once on the page`,
        );
      e.numAttemptedScriptInits++;
    } else {
      Pt();
      if (Vt()) {
        const e = () => {
          document.removeEventListener("DOMContentLoaded", e);
          Ot.init();
        };
        document.addEventListener("DOMContentLoaded", e);
      } else Ot.init();
    }
  })();
})();
