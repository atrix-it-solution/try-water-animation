import React from 'react';

const App = () => {
  return (
    <div className="page_wrapp">
      <div className="main-css w-embed">
        <style
          dangerouslySetInnerHTML={{
            __html: `
  body {
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    font-smoothing: antialiased;
    text-rendering: optimizeLegibility;
    transition: background-color 0.4s;
  }

  .text--grad {
    background: linear-gradient(265.26deg, #08906c 38.04%, #34bf99 94.86%);
    background-clip: text;
    color: transparent;
  }

  .footer_sn-icon rect,
  .footer_sn-icon path {
    transition: fill 0.3s ease;
  }

  .footer_sn-icon:hover rect {
    fill: #ffffff;
  }

  .footer_sn-icon:hover path {
    fill: #08906c;
  }

  .hubspot_form {
    overflow: auto;
  }
`,
          }}
        />
      </div>
      <div className="onpage_css w-embed">
        <style
          dangerouslySetInnerHTML={{
            __html: `
  .line {
    overflow: hidden;
  }

  .animate-text_opacity {
    overflow: hidden;
  }

  .animate-text_opacity [aria-hidden='true'] {
    will-change: opacity;
  }

  .impact-item .text--number {
    color: var(--_zig---colors--green-500);
  }
  .impact-item .text--l {
    color: var(--_zig---colors--gray-600);
  }

  @media screen and (min-width: 992px) {
    .impact-item:hover .impact-bg {
      transform: scale(1, 1);
    }
    .impact-item:hover .text--number {
      color: var(--_zig---colors--white);
    }
    .impact-item:hover .text--l {
      color: var(--_zig---colors--green-200);
    }
  }

  @media screen and (max-width: 480px) {
    .splide__pagination {
      position: static;
    }
  }

  .splide__pagination {
    width: auto;
    height: var(--_zig---base-size--44);
    gap: var(--_zig---base-size--12);
    border-radius: var(--_zig---base-size--20);
    justify-content: flex-start;
    align-items: center;
    display: flex;
    position: absolute;
    inset: auto auto 0% 0%;
    padding: 0;
    margin: 0;
    list-style: none;
  }

  .splide__pagination__page {
    width: var(--_zig---base-size--42);
    height: 2px;
    border-radius: var(--_zig---base-size--40);
    background-color: #fff3;
    border: none;
    padding: 0;
    cursor: pointer;
    overflow: clip;
    transform: none;
    opacity: 1;
  }

  .splide__pagination__page.is-active {
    background-color: #fff;
    transform: none;
  }

  .splide__sr {
    display: none;
  }

  .trusted-track {
    -webkit-mask-image: linear-gradient(90deg, #000 0%, #000 92%, transparent 100%);
    mask-image: linear-gradient(90deg, #000 0%, #000 92%, transparent 100%);
  }

  @media (max-width: 480px) {
    .trusted-track {
      -webkit-mask-image: linear-gradient(90deg, transparent, #000 8%, #000 92%, transparent);
      mask-image: linear-gradient(90deg, transparent, #000 8%, #000 92%, transparent);
    }
  }
`,
          }}
        />
      </div>

      {/* Modal */}
      <div data-modal="cta" className="modal-component">
        <div data-modal="close" className="form-modal__bg"></div>
        <div className="modal_wrapp">
          <div data-modal="close" className="modal__close">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="100%"
              viewBox="0 0 24 24"
              fill="none"
              className="close--icon"
            >
              <path
                d="M21 21L3 3M21.0001 3L3 21.0001"
                stroke="#15171A"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
          <div className="hubspot_form w-embed w-script">
            <div
              className="hs-form-frame"
              data-region="na2"
              data-form-id="b9003760-92fc-4558-85ce-1668b1feb822"
              data-portal-id="244756941"
            ></div>
          </div>
        </div>
      </div>

      {/* Navbar */}
      <div
        data-animation="over-right"
        className="navbar w-nav"
        data-wf--navbar--variant="base"
        data-easing2="ease"
        data-easing="ease"
        data-collapse="medium"
        data-w-id="a7bc8a10-fdd2-7358-97a0-ee55c54de030"
        role="banner"
        data-duration="400"
      >
        <div className="w-layout-vflex nav_container">
          <a href="/" aria-current="page" className="nav_logo w-inline-block w--current">
            <div className="logo_img is--desk w-embed">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="100%"
                height="100%"
                viewBox="0 0 104 30"
                fill="none"
                preserveAspectRatio="xMidYMid meet"
                aria-hidden="true"
                role="img"
              >
                <path
                  d="M99.9691 21.8315V6.65317H103.536V21.8315H99.9691ZM101.765 4.19934C101.175 4.19934 100.677 3.99696 100.273 3.59221C99.8679 3.17059 99.6655 2.67307 99.6655 2.09967C99.6655 1.49254 99.8679 0.995025 100.273 0.607133C100.694 0.202378 101.192 0 101.765 0C102.372 0 102.87 0.202378 103.258 0.607133C103.662 1.01189 103.865 1.5094 103.865 2.09967C103.865 2.68994 103.662 3.18745 103.258 3.59221C102.853 3.99696 102.355 4.19934 101.765 4.19934Z"
                  fill="#15171A"
                />
                <path
                  d="M89.4569 22.1351C88.074 22.1351 86.8092 21.7809 85.6624 21.0726C84.5155 20.3643 83.5964 19.4114 82.905 18.214C82.2304 17.0166 81.8931 15.6927 81.8931 14.2423C81.8931 12.792 82.2304 11.4681 82.905 10.2707C83.5964 9.07328 84.5155 8.12042 85.6624 7.41209C86.8092 6.70377 88.074 6.34961 89.4569 6.34961C90.4688 6.34961 91.4048 6.53512 92.2649 6.90615C93.1419 7.26031 93.8924 7.76626 94.5164 8.42398V6.65318H97.6785V21.8315H94.5164V20.0607C93.8924 20.7016 93.1419 21.2075 92.2649 21.5785C91.4048 21.9496 90.4688 22.1351 89.4569 22.1351ZM89.9123 18.9476C90.7555 18.9476 91.5229 18.7368 92.2143 18.3152C92.9227 17.8936 93.4792 17.3286 93.884 16.6203C94.3056 15.912 94.5164 15.1193 94.5164 14.2423C94.5164 13.3822 94.3056 12.598 93.884 11.8897C93.4792 11.1645 92.9311 10.5911 92.2396 10.1695C91.5482 9.74787 90.7724 9.53706 89.9123 9.53706C89.069 9.53706 88.2933 9.74787 87.5849 10.1695C86.8935 10.5911 86.3369 11.1561 85.9153 11.8644C85.5106 12.5727 85.3082 13.3654 85.3082 14.2423C85.3082 15.1025 85.5106 15.8951 85.9153 16.6203C86.3369 17.3286 86.8935 17.8936 87.5849 18.3152C88.2764 18.7368 89.0522 18.9476 89.9123 18.9476Z"
                  fill="#15171A"
                />
                <path
                  d="M78.9469 22.237C78.2892 22.237 77.7326 22.0093 77.2773 21.554C76.8219 21.0986 76.5942 20.5421 76.5942 19.8844C76.5942 19.2098 76.8219 18.6532 77.2773 18.2148C77.7326 17.7594 78.2892 17.5317 78.9469 17.5317C79.6383 17.5317 80.2033 17.7594 80.6418 18.2148C81.0971 18.6701 81.3248 19.2267 81.3248 19.8844C81.3248 20.5421 81.0971 21.0986 80.6418 21.554C80.2033 22.0093 79.6383 22.237 78.9469 22.237Z"
                  fill="#08906C"
                />
                <path
                  d="M54.391 21.8315V6.65317H57.9579V21.8315H54.391ZM56.1871 4.19934C55.5968 4.19934 55.0993 3.99696 54.6945 3.59221C54.2898 3.17059 54.0874 2.67307 54.0874 2.09967C54.0874 1.49254 54.2898 0.995025 54.6945 0.607133C55.1162 0.202378 55.6137 0 56.1871 0C56.7942 0 57.2917 0.202378 57.6796 0.607133C58.0844 1.01189 58.2867 1.5094 58.2867 2.09967C58.2867 2.68994 58.0844 3.18745 57.6796 3.59221C57.2749 3.99696 56.7773 4.19934 56.1871 4.19934Z"
                  fill="#15171A"
                />
                <path
                  d="M36.0283 21.8886L46.5878 9.75916H36.4728V6.75293H53.0576L42.4981 18.8824H52.6632V21.8886H36.0283Z"
                  fill="#15171A"
                />
                <path
                  d="M66.918 6.34912C67.9297 6.34917 68.8656 6.53479 69.7256 6.90576C70.6024 7.25985 71.3526 7.76582 71.9766 8.42334V6.65283H75.1396V21.9321C75.1396 23.5848 74.7428 25.0016 73.9502 26.1821C73.1745 27.3626 72.1374 28.2652 70.8389 28.8892C69.5404 29.5131 68.1405 29.8247 66.6396 29.8247C65.476 29.8247 64.3879 29.6561 63.376 29.3188C63.1604 29.247 62.9512 29.1678 62.7471 29.0845V25.3354C63.0393 25.5632 63.3579 25.7708 63.7051 25.9546C64.5651 26.4267 65.5435 26.6626 66.6396 26.6626C68.2585 26.6625 69.5485 26.1824 70.5098 25.2212C71.471 24.2768 71.9521 23.0456 71.9521 21.5278V20.0854C71.3282 20.7263 70.5857 21.233 69.7256 21.604C68.8656 21.9581 67.9297 22.1352 66.918 22.1353C65.5351 22.1353 64.2698 21.781 63.123 21.0728C61.9762 20.3644 61.0567 19.4108 60.3652 18.2134C59.6908 17.0161 59.3535 15.6919 59.3535 14.2417C59.3536 12.7915 59.6907 11.4673 60.3652 10.27C61.0567 9.07269 61.9763 8.11991 63.123 7.41162C64.2698 6.70336 65.5351 6.34912 66.918 6.34912ZM67.373 9.53662C66.5299 9.53662 65.7542 9.74788 65.0459 10.1694C64.3545 10.591 63.7976 11.1556 63.376 11.8638C62.9713 12.572 62.7686 13.3649 62.7686 14.2417C62.7686 15.1017 62.9713 15.8945 63.376 16.6196C63.7976 17.328 64.3544 17.8933 65.0459 18.3149C65.7373 18.7365 66.513 18.9478 67.373 18.9478C68.2162 18.9477 68.9834 18.7365 69.6748 18.3149C70.3831 17.8933 70.94 17.328 71.3447 16.6196C71.7662 15.9114 71.9766 15.1185 71.9766 14.2417C71.9765 13.3817 71.7663 12.5974 71.3447 11.8892C70.94 11.1641 70.3916 10.591 69.7002 10.1694C69.0088 9.74784 68.2331 9.53664 67.373 9.53662Z"
                  fill="#15171A"
                />
                <path
                  d="M14.2806 11.957C14.6801 11.2604 15.7474 11.4881 15.8219 12.2859L16.6163 20.8001C16.6523 21.1854 16.9557 21.4932 17.3436 21.5379L33.6733 23.4184C34.619 23.5273 34.6595 24.8732 33.7221 25.0377L5.49841 29.9867C4.80967 30.1075 4.2904 29.3786 4.6359 28.776L14.2806 11.957Z"
                  fill="#08906C"
                />
                <path
                  d="M28.906 0.16217C29.5947 0.0414182 30.114 0.770326 29.7685 1.37283L20.1235 18.1919C19.724 18.8885 18.6567 18.6607 18.5822 17.863L17.7881 9.34881C17.7521 8.96346 17.4485 8.65567 17.0605 8.61099L0.73084 6.73021C-0.214806 6.62121 -0.255196 5.27531 0.682314 5.11092L28.906 0.16217Z"
                  fill="#08906C"
                />
              </svg>
            </div>
          </a>
          <nav
            role="navigation"
            id="w-node-a7bc8a10-fdd2-7358-97a0-ee55c54de034-c54de030"
            className="nav_links w-nav-menu"
          >
            <div className="w-layout-vflex nav_links-content">
              <a href="/how-it-works" className="navlink w-nav-link">
                How It Works
              </a>
              <a href="/pricing" className="navlink w-nav-link">
                Pricing
              </a>
              <a href="/about" className="navlink w-nav-link">
                About Zig
              </a>
              <a href="/blog" className="navlink w-nav-link">
                Blog
              </a>
              <div className="nav_links-button">
                <a
                  data-modal-open=""
                  data-wf--button--variant="primary-s"
                  href="http://app.zig.ai/"
                  target="_blank"
                  className="button w-variant-987f400b-b846-238a-7f65-5fa18cfecfa3 w-inline-block"
                >
                  <div>Login</div>
                </a>
                <a
                  data-modal-open=""
                  data-wf--button--variant="secondary-s"
                  href="/book-a-meeting"
                  className="button w-variant-05364811-9faf-2d5c-060a-a42f79515f00 w-inline-block"
                >
                  <div>Book a demo</div>
                </a>
              </div>
            </div>
          </nav>
          <div className="button_navbar btn-bar">
            <a
              data-modal-open=""
              data-wf--button--variant="tertiary-s"
              href="/book-a-meeting"
              className="button w-variant-069eda21-72c1-d9fc-63ae-ff327d98e2a0 w-inline-block"
            >
              <div>Book a demo</div>
            </a>
            <a
              data-modal-open=""
              data-wf--button--variant="primary-s"
              href="http://app.zig.ai/"
              target="_blank"
              className="button w-variant-987f400b-b846-238a-7f65-5fa18cfecfa3 w-inline-block"
            >
              <div>Login</div>
            </a>
          </div>
          <div className="menu-button w-nav-button">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="100%"
              viewBox="0 0 36 36"
              fill="none"
              className="burger_icon is--open"
            >
              <path
                d="M4.5 12.75H31.5M4.5 23.25H31.5"
                stroke="#15171A"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="100%"
              viewBox="0 0 36 36"
              fill="none"
              className="burger_icon is--close"
            >
              <path
                d="M27 9L9 27M9 9L27 27"
                stroke="#15171A"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
        </div>
        <div className="nav_bg" style={{ opacity: 0, transition: 'opacity 0.3s' }}></div>
      </div>

      {/* Main */}
      <main className="main_wrapp">
        {/* Hero Section */}
        <section className="section hero_section">
          <div className="padding_global is--static">
            <div className="w-layout-vflex container">
              <div className="hero_container-new">
                <div className="w-layout-vflex hero_component-new">
                  <div className="hero_content-new">
                    <div data-wf--section-chips--variant="base" className="section_chips">
                      <img
                        loading="lazy"
                        src="images/6a2ade093d4ed3f8ed40f59a_b02bd53e80ae3ff609dc26af780b742d_Icon.svg"
                        alt=""
                        className="icon_chips"
                      />
                      <div>AI Assistants for Sales Reps</div>
                    </div>
                    <h1 className="title--xl">
                      Close deals.
                      <br />
                      <span className="text--grad">Zig handles the rest.</span>
                    </h1>
                    <div className="w-layout-vflex hero__description-new">
                      <p className="text--l">
                        Your own team of AI assistants — take out one per workflow. They research,
                        outreach, prep, follow up, and log. You approve and close.
                        <br />
                      </p>
                    </div>
                  </div>
                  <div className="w-layout-vflex hero_buttons-wrapp">
                    <a
                      data-modal-open=""
                      data-wf--button--variant="primary-m"
                      href="/book-a-meeting"
                      className="button w-inline-block"
                    >
                      <div>Start Now</div>
                    </a>
                    <a
                      data-modal-open=""
                      data-wf--button--variant="tertiary-m"
                      href="/book-a-meeting"
                      className="button w-variant-8ab93cf4-d629-81e6-e7fb-0245c8a1d5ff w-inline-block"
                    >
                      <div>Book a demo for a Team</div>
                    </a>
                  </div>
                </div>
                <div className="hero-animation_wrapp">
                  <div
                    className="hero_lottie _1280"
                    data-w-id="e22a8e64-76c5-ec90-dab3-4caedf46f890"
                    data-animation-type="lottie"
                    data-src="https://cdn.prod.website-files.com/692db0eaf3c473ac91a06392/6a33e33f6042414d2340012a_93df246aa189ea66a4abed5d901e8533_Homepage%20Hero%20%E2%80%94%20Motion_2500.lottie"
                    data-loop="1"
                    data-direction="1"
                    data-autoplay="1"
                    data-is-ix2-target="0"
                    data-renderer="canvas"
                    data-default-duration="0"
                    data-duration="8"
                    data-loading="lazy"
                  ></div>
                  <div
                    className="hero_lottie desktop"
                    data-w-id="e22a8e64-76c5-ec90-dab3-4caedf46f891"
                    data-animation-type="lottie"
                    data-src="https://cdn.prod.website-files.com/692db0eaf3c473ac91a06392/6a4271bb54dbd7a2df1642e3_aeed43bf3b730e548c909a40b9344278_Homepage%20Hero%20%E2%80%94%20Motion_1280.lottie"
                    data-loop="1"
                    data-direction="1"
                    data-autoplay="1"
                    data-is-ix2-target="0"
                    data-renderer="canvas"
                    data-default-duration="0"
                    data-duration="8"
                    data-loading="lazy"
                  ></div>
                  <div
                    className="hero_lottie tablet"
                    data-w-id="e22a8e64-76c5-ec90-dab3-4caedf46f892"
                    data-animation-type="lottie"
                    data-src="https://cdn.prod.website-files.com/692db0eaf3c473ac91a06392/6a426cad8ba4eb299e327813_8ffbf03408276c0100d2c18bc7ce9912_Homepage%20Hero%20%E2%80%94%20Motion_820%20%281%29.lottie"
                    data-loop="1"
                    data-direction="1"
                    data-autoplay="1"
                    data-is-ix2-target="0"
                    data-renderer="canvas"
                    data-default-duration="0"
                    data-duration="8"
                    data-loading="lazy"
                  ></div>
                  <div
                    className="hero_lottie mobile"
                    data-w-id="e22a8e64-76c5-ec90-dab3-4caedf46f893"
                    data-animation-type="lottie"
                    data-src="https://cdn.prod.website-files.com/692db0eaf3c473ac91a06392/6a426cadc63f603a8b1699a7_e85e91fad1396a64c046d353727b94ea_Homepage%20Hero%20%E2%80%94%20Motion_420.lottie"
                    data-loop="1"
                    data-direction="1"
                    data-autoplay="1"
                    data-is-ix2-target="0"
                    data-renderer="canvas"
                    data-default-duration="0"
                    data-duration="8"
                    data-loading="lazy"
                  ></div>
                  <div className="hero-animation_grad"></div>
                  <div className="hero-animation_grad is--right"></div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Benefits / Execution Gap Section */}
        <section className="section main-large is--bg-white">
          <div className="padding_global">
            <div className="w-layout-vflex container">
              <div className="w-layout-vflex benefits_header-new animate-block_appear">
                <div data-wf--section-chips--variant="base" className="section_chips">
                  <img
                    loading="lazy"
                    src="images/6a2ae04928fffdcec95313ae_d8d09b442fc8bac3c3dfa5c87774475d_Expand%20Icon.svg"
                    alt=""
                    className="icon_chips"
                  />
                  <div>The execution gap</div>
                </div>
                <h2 className="title--l">
                  You didn't get into sales to do <span className="text--grad">data entry</span>
                </h2>
              </div>
              <div className="spacer spacer-60"></div>
              <div className="benefits_grid">
                <div
                  id="w-node-e22a8e64-76c5-ec90-dab3-4caedf46f8a2-62a4fde0"
                  className="w-layout-vflex benefits"
                >
                  <div className="w-layout-vflex benefits_chips">
                    <p className="text--chips">Before</p>
                    <img
                      src="images/6a2ae0c52c00f4b73a109602_Tag%20Icon.svg"
                      loading="lazy"
                      alt=""
                      className="image-5"
                    />
                  </div>
                  <div className="hiw-benefits_list">
                    <div className="w-layout-vflex benefits_item">
                      <div className="benefit_marker">
                        <img
                          src="images/6a2ae1aa14a73969a4f78b24_Close%20Icon.svg"
                          loading="lazy"
                          alt=""
                          className="icon_14px"
                        />
                      </div>
                      <div className="title--xs">
                        You log into 8 tools to close
                        <br />
                        one deal.
                      </div>
                    </div>
                    <div className="w-layout-vflex benefits_item">
                      <div className="benefit_marker">
                        <img
                          src="images/6a2ae1aa14a73969a4f78b24_Close%20Icon.svg"
                          loading="lazy"
                          alt=""
                          className="icon_14px"
                        />
                      </div>
                      <div className="title--xs">
                        You spend 40 minutes after every call on work nobody built a tool to handle
                        <br />
                      </div>
                    </div>
                    <div className="w-layout-vflex benefits_item">
                      <div className="benefit_marker">
                        <img
                          src="images/6a2ae1aa14a73969a4f78b24_Close%20Icon.svg"
                          loading="lazy"
                          alt=""
                          className="icon_14px"
                        />
                      </div>
                      <div className="title--xs">
                        Your CRM is a to-do list you silently agreed to ignore. The board notices.
                        <br />
                      </div>
                    </div>
                    <div className="w-layout-vflex benefits_item is--last">
                      <div className="benefit_marker">
                        <img
                          src="images/6a2ae1aa14a73969a4f78b24_Close%20Icon.svg"
                          loading="lazy"
                          alt=""
                          className="icon_14px"
                        />
                      </div>
                      <div className="title--xs">
                        Your best rep is spending half their week not selling.
                        <br />
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  id="w-node-e22a8e64-76c5-ec90-dab3-4caedf46f8c1-62a4fde0"
                  className="w-layout-vflex benefits"
                >
                  <div className="w-layout-vflex benefits_chips is--green">
                    <p className="text--chips">After</p>
                    <img
                      src="images/6a2ae0c52c00f4b73a109602_Tag%20Icon.svg"
                      loading="lazy"
                      alt=""
                      className="image-5"
                    />
                  </div>
                  <div className="hiw-benefits_list">
                    <div className="w-layout-vflex benefits_item">
                      <div className="benefit_marker is--green">
                        <img
                          src="images/6a2ae1aa394b8dfaeee438b2_Check%20Icon.svg"
                          loading="lazy"
                          alt=""
                          className="icon_14px"
                        />
                      </div>
                      <div className="w-layout-vflex benefit_text">
                        <div className="title--xs is--green">
                          Every action logged. You didn't touch a thing.
                        </div>
                      </div>
                    </div>
                    <div className="w-layout-vflex benefits_item">
                      <div className="benefit_marker is--green">
                        <img
                          src="images/6a2ae1aa394b8dfaeee438b2_Check%20Icon.svg"
                          loading="lazy"
                          alt=""
                          className="icon_14px"
                        />
                      </div>
                      <div className="w-layout-vflex benefit_text">
                        <div className="title--xs is--green">
                          Follow-up sent before you finished the next call.
                        </div>
                      </div>
                    </div>
                    <div className="w-layout-vflex benefits_item">
                      <div className="benefit_marker is--green">
                        <img
                          src="images/6a2ae1aa394b8dfaeee438b2_Check%20Icon.svg"
                          loading="lazy"
                          alt=""
                          className="icon_14px"
                        />
                      </div>
                      <div className="w-layout-vflex benefit_text">
                        <div className="title--xs is--green">
                          Your reps are selling. Not administrating.
                        </div>
                      </div>
                    </div>
                    <div className="w-layout-vflex benefits_item is--last">
                      <div className="benefit_marker is--green">
                        <img
                          src="images/6a2ae1aa394b8dfaeee438b2_Check%20Icon.svg"
                          loading="lazy"
                          alt=""
                          className="icon_14px"
                        />
                      </div>
                      <div className="title--xs is--green">
                        A pipeline your manager can defend to the board.
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Animated Title Section */}
        <section className="section main-large">
          <div className="padding_global">
            <div className="w-layout-vflex container">
              <div
                id="w-node-e22a8e64-76c5-ec90-dab3-4caedf46f8e1-62a4fde0"
                className="w-layout-vflex animated_title"
              >
                <h2
                  id="w-node-e22a8e64-76c5-ec90-dab3-4caedf46f8e2-62a4fde0"
                  className="title--l animate-text_opacity"
                >
                  Zig doesn't speed up admin.
                  <br />
                  <span className="is--light-green">
                    It gives the rep a team that runs it.
                  </span>
                </h2>
              </div>
            </div>
          </div>
        </section>

        {/* Trusted By Section */}
        <section className="section">
          <div className="padding_global">
            <div className="w-layout-vflex container">
              <div
                data-w-id="1c97c66c-14c5-df64-1e1f-0f58f91a9f6d"
                className="w-layout-vflex trusted-container"
              >
                <div className="trusted-wrapp">
                  <div className="title--s is--gray-600">Trusted by</div>
                  <div className="trusted-track">
                    <div className="trusted-list">
                      <img
                        src="images/6a5df95bee9272a0cc668d3d_Ketch%20Logo.svg"
                        loading="lazy"
                        alt=""
                        className="trusted-logo"
                      />
                      <img
                        src="images/6a5df95c395883bf3f77d903_Velociti%20Logo.svg"
                        loading="lazy"
                        alt=""
                        className="trusted-logo"
                      />
                      <img
                        src="images/6a5df95bbce231501b99e7fb_Velociti%20Logo-1.svg"
                        loading="lazy"
                        alt=""
                        className="trusted-logo"
                      />
                      <img
                        src="images/6a5df95be65d6d822476ea92_Checksum%20Logo.svg"
                        loading="lazy"
                        alt=""
                        className="trusted-logo"
                      />
                      <img
                        src="images/6a607174d8723e617a1f1bfa_SellingSara%20Logo.svg"
                        loading="lazy"
                        alt=""
                        className="trusted-logo"
                      />
                    </div>
                    <div className="trusted-list">
                      <img
                        src="images/6a5df95bee9272a0cc668d3d_Ketch%20Logo.svg"
                        loading="lazy"
                        alt=""
                        className="trusted-logo"
                      />
                      <img
                        src="images/6a5df95c395883bf3f77d903_Velociti%20Logo.svg"
                        loading="lazy"
                        alt=""
                        className="trusted-logo"
                      />
                      <img
                        src="images/6a5df95bbce231501b99e7fb_Velociti%20Logo-1.svg"
                        loading="lazy"
                        alt=""
                        className="trusted-logo"
                      />
                      <img
                        src="images/6a5df95be65d6d822476ea92_Checksum%20Logo.svg"
                        loading="lazy"
                        alt=""
                        className="trusted-logo"
                      />
                      <img
                        src="images/6a607174d8723e617a1f1bfa_SellingSara%20Logo.svg"
                        loading="lazy"
                        alt=""
                        className="trusted-logo"
                      />
                    </div>
                    <div className="trusted-list">
                      <img
                        src="images/6a5df95bee9272a0cc668d3d_Ketch%20Logo.svg"
                        loading="lazy"
                        alt=""
                        className="trusted-logo"
                      />
                      <img
                        src="images/6a5df95c395883bf3f77d903_Velociti%20Logo.svg"
                        loading="lazy"
                        alt=""
                        className="trusted-logo"
                      />
                      <img
                        src="images/6a5df95bbce231501b99e7fb_Velociti%20Logo-1.svg"
                        loading="lazy"
                        alt=""
                        className="trusted-logo"
                      />
                      <img
                        src="images/6a5df95be65d6d822476ea92_Checksum%20Logo.svg"
                        loading="lazy"
                        alt=""
                        className="trusted-logo"
                      />
                      <img
                        src="images/6a607174d8723e617a1f1bfa_SellingSara%20Logo.svg"
                        loading="lazy"
                        alt=""
                        className="trusted-logo"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Built Different Section */}
        <section data-w-id="e22a8e64-76c5-ec90-dab3-4caedf46f8e7" className="section main-large">
          <div className="padding_global">
            <div className="w-layout-vflex container">
              <div className="w-layout-vflex section_heading animate-block_appear">
                <div data-wf--section-chips--variant="base" className="section_chips">
                  <img
                    loading="lazy"
                    src="images/6a2ba47a3fac7258e1e616b1_5f7fbb6e08355e7f25447873f71cf0fa_Lightbulb%20Icon.svg"
                    alt=""
                    className="icon_chips"
                  />
                  <div>Built different</div>
                </div>
                <div className="w-layout-vflex built_title">
                  <h2 className="title--l">
                    <span className="text--grad">Why Zig is different</span> from everything else
                    you've tried
                  </h2>
                </div>
                <p className="text--l">
                  Most sales tools wait to be used. Zig is the AI employee that never stops working.
                </p>
              </div>
              <div className="spacer spacer-60"></div>
              <div className="built-container">
                <div
                  id="w-node-e22a8e64-76c5-ec90-dab3-4caedf46f8f6-62a4fde0"
                  className="built-card is--wide"
                >
                  <div className="built-card-content">
                    <div className="text--mono is--grey">/ 01</div>
                    <div className="title--m">Full revenue motion</div>
                    <p className="text--m">
                      From ICP to closed deal — research, outreach, meetings, follow-ups, CRM,
                      pipeline — all connected. No other platform covers more than three stages.
                      Zig covers all of them, and they talk to each other.
                    </p>
                  </div>
                  <img
                    src="images/6a2bab8643ca2678a85b67a4_885fd6d13eedb034ff9318901d56aab2_built-img--1.avif"
                    loading="lazy"
                    width="499.5"
                    alt=""
                    className="built-img-01"
                  />
                </div>
                <div className="built-card is--accent-red">
                  <div className="built-card-content">
                    <div className="text--mono opacity-60">
                      / 02
                      <br />
                    </div>
                    <div className="title--m">Field-first mobile</div>
                    <p className="text--m">
                      Scan a badge, a business card, or a handwritten name. Instantly: LinkedIn
                      profile, email, phone, full company research. Ready to talk before the
                      conversation starts. Your desk is wherever you're selling.
                      <br />
                    </p>
                  </div>
                  <img
                    src="images/6a2bab86c0baa426682eac51_built-img--2.avif"
                    loading="lazy"
                    width="628"
                    alt=""
                    className="built-img-02"
                  />
                </div>
                <div className="built-card is--accent-green">
                  <div className="built-card-content">
                    <div className="text--mono opacity-60">
                      / 03
                      <br />
                    </div>
                    <div className="title--m">Always working. Never waiting.</div>
                    <p className="text--m">
                      Zig doesn't sit in a tab waiting to be opened. It surfaces actions before the
                      rep thinks to look, listens during calls, and executes downstream —
                      automatically.
                    </p>
                  </div>
                  <img
                    src="images/6a2bab86466f4a6f19e95059_b211bcb409c270226bd051b224cd418d_built-img--3.avif"
                    loading="lazy"
                    width="384"
                    alt=""
                    className="built-img-03"
                  />
                </div>
                <div className="built-card">
                  <div className="built-card-content">
                    <div className="text--mono is--grey">
                      / 04
                      <br />
                    </div>
                    <div className="title--m">The rep stays in control</div>
                    <p className="text--m">
                      Complex actions require approval. Simple ones just happen. Every execution is
                      visible, reviewable, and reversible. Enterprise-ready by design.
                    </p>
                  </div>
                  <img
                    src="images/6a2bab86772ae44669db2e29_built-img--4.avif"
                    loading="lazy"
                    width="409"
                    alt=""
                    className="built-img-04"
                  />
                </div>
                <div className="built-card">
                  <div className="built-card-content">
                    <div className="text--mono is--grey">
                      / 05
                      <br />
                    </div>
                    <div className="title--m">Your agent on the phone</div>
                    <p className="text--m">
                      Call your Zig agent from the car. "Send the follow-up. Update the CRM. Call
                      Emily and offer her times from my calendar." It handles it. No laptop
                      required.
                    </p>
                  </div>
                  <img
                    src="images/6a2bab863fac7258e1e903bd_65c3dd6d7eb826dde7209141a62eece1_built-img--5.avif"
                    loading="lazy"
                    width="189.5"
                    alt=""
                    className="built-img-05"
                  />
                </div>
                <div
                  id="w-node-e22a8e64-76c5-ec90-dab3-4caedf46f928-62a4fde0"
                  className="built-card is--wide-accent"
                >
                  <div className="built-card-content">
                    <div className="text--mono opacity-60">
                      / 06
                      <br />
                    </div>
                    <div className="title--m">Intelligence trained on your data</div>
                    <p className="text--m">
                      Not generic AI. Revenue Intelligence that learns from your actual deals, your
                      actual wins, your actual buyers — and gets sharper every month.
                    </p>
                  </div>
                  <img
                    src="images/6a2bab865e1c44ad05720c06_65510cb5ecf042fe859f4d50ae142691_built-img--6.avif"
                    loading="lazy"
                    width="501"
                    alt=""
                    className="built-img-06"
                  />
                  <img
                    src="images/6a2bab865e3ef1f56fad87b7_built-img--6-mob.avif"
                    loading="lazy"
                    width="501"
                    alt=""
                    className="built-img-06--mob"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Impact Section */}
        <div
          data-w-id="e22a8e64-76c5-ec90-dab3-4caedf46f933"
          className="w-layout-vflex impact-animation-track"
        >
          <section className="section impact-section">
            <div className="padding_global">
              <div className="w-layout-vflex container-impact">
                <div className="w-layout-vflex impact-section_heading animate-block_appear">
                  <div data-wf--section-chips--variant="base" className="section_chips">
                    <img
                      loading="lazy"
                      src="images/6a2baff6be86b18d52d34a87_678c4ed9c7f0fe2b3dbca4429bca2c4b_Icon3.svg"
                      alt=""
                      className="icon_chips"
                    />
                    <div>The impact</div>
                  </div>
                  <div className="w-layout-vflex impact_title">
                    <h2 className="title--l">
                      What changes <span className="text--grad">when Zig runs</span>
                    </h2>
                  </div>
                  <p className="text--l">What happens when the rep finally has a team.</p>
                </div>
                <div className="impact-list">
                  <div className="impact-item is--01">
                    <div className="impact-content">
                      <div className="text--number">60+</div>
                      <div className="text--l">Hours back. Per rep. Every month.</div>
                    </div>
                    <div className="impact-bg"></div>
                  </div>
                  <div className="impact-item is--02">
                    <div className="impact-content">
                      <div className="text--number">95%</div>
                      <div className="text--l">CRM accuracy. Zero manual entry.</div>
                    </div>
                    <div className="impact-bg"></div>
                  </div>
                  <div className="impact-item is--03">
                    <div className="impact-content">
                      <div className="text--number">30%</div>
                      <div className="text--l">Faster from first touch to close.</div>
                    </div>
                    <div className="impact-bg"></div>
                  </div>
                  <div className="impact-item is--04">
                    <div className="impact-content">
                      <div className="text--number">3x</div>
                      <div className="text--l">
                        Revenue impact. Measured across real deployments.
                      </div>
                    </div>
                    <div className="impact-bg"></div>
                  </div>
                  <div className="impact-item-accent">
                    <div className="w-layout-vflex impact-item-accent-text">
                      <p className="title--m">
                        The longer it runs, the wider the gap between you and everyone starting
                        fresh.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>

        {/* Wins Animation Track */}
        <div
          data-w-id="e22a8e64-76c5-ec90-dab3-4caedf46f962"
          className="w-layout-vflex wins-animation-track"
        >
          <section className="section main-large">
            <div className="padding_global">
              <div className="w-layout-vflex container">
                <div className="w-layout-vflex steps-section-title">
                  <div className="w-layout-vflex section_heading animate-block_appear">
                    <div
                      data-wf--section-chips--variant="dark"
                      className="section_chips w-variant-28ba76d0-08d9-d4d7-40be-ef11d536cd9f"
                    >
                      <img
                        loading="lazy"
                        src="images/6a2bb5f230f5600b18d92d3c_f5806a04f77d5f96be5623316e89377c_Tagline%20Icon.svg"
                        alt=""
                        className="icon_chips"
                      />
                      <div>One platform. Two wins</div>
                    </div>
                    <div className="w-layout-vflex win_title">
                      <h2 className="title--l">
                        The rep closes.
                        <br />
                        The leader has their back.
                      </h2>
                      <div className="w-layout-vflex win_sub">
                        <p className="text--l">
                          The rep stops administrating. The leader stops guessing. The number starts
                          moving.
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="w-layout-vflex steps-btns">
                    <a
                      data-modal-open=""
                      data-wf--button--variant="primary-m"
                      href="/book-a-meeting"
                      className="button w-inline-block"
                    >
                      <div>Start Now</div>
                    </a>
                    <a
                      data-modal-open=""
                      data-wf--button--variant="tertiary-m-white"
                      href="/book-a-meeting"
                      className="button w-variant-6101740f-88aa-0a0a-23a7-024ce8ee2b35 w-inline-block"
                    >
                      <div>Book a demo for a Team</div>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Wins Section */}
          <section className="section wins-section">
            <div className="padding_global">
              <div className="w-layout-vflex container">
                <div className="win-circles-wrapp">
                  <div className="win-circle illustration">
                    <img
                      src="images/6a2bbc88b9b3fcc05f3c1d04_5ccd0447c27a19ea6d5ba4313c11b518_Frame%202136140972.avif"
                      loading="lazy"
                      sizes="100vw"
                      srcSet="images/6a2bbc88b9b3fcc05f3c1d04_5ccd0447c27a19ea6d5ba4313c11b518_Frame%202136140972-p-500.avif 500w, images/6a2bbc88b9b3fcc05f3c1d04_5ccd0447c27a19ea6d5ba4313c11b518_Frame%202136140972.avif 618w"
                      alt=""
                      className="win-circle-img"
                    />
                  </div>
                  <div className="win-circle is--left">
                    <div className="w-layout-vflex win-circle-content is--left">
                      <div className="w-layout-vflex win-circle-text">
                        <div className="title--m">For the rep doing the closing</div>
                      </div>
                    </div>
                    <div className="win-tooltips is--left">
                      <div className="w-layout-vflex win-tooltip is--01">
                        <p className="text--l">
                          60+ hours back. Every month. Automatically.
                        </p>
                      </div>
                      <div className="w-layout-vflex win-tooltip is--02">
                        <p className="text--l">
                          Finds leads, drafts outreach, joins calls, writes follow-ups.
                        </p>
                      </div>
                      <div className="w-layout-vflex win-tooltip is--03">
                        <p className="text--l">
                          Wherever you sell — desktop, phone, voice, or text.
                          <br />
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="win-circle is--right">
                    <div className="w-layout-vflex win-circle-content is--right">
                      <div className="w-layout-vflex win-circle-text">
                        <div className="title--m">For the leader running the number</div>
                      </div>
                    </div>
                    <div className="win-tooltips is--right">
                      <div className="w-layout-vflex win-tooltip is--01-right">
                        <p className="text--l">
                          Pipeline that finally mirrors reality. CRM that survives the quarter.
                        </p>
                      </div>
                      <div className="w-layout-vflex win-tooltip is--02">
                        <p className="text--l">
                          One layer that replaces Apollo, Gong, Salesloft, and the notetaker.
                        </p>
                      </div>
                      <div className="w-layout-vflex win-tooltip is--03-right">
                        <p className="text--l">
                          At month 12, knows your deals better than any new hire.
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="code-embed w-embed">
                    <svg
                      className="win-svg-overlay"
                      style={{
                        position: 'absolute',
                        inset: 0,
                        width: '100%',
                        height: '100%',
                        pointerEvents: 'none',
                        overflow: 'visible',
                        opacity: 0,
                      }}
                    ></svg>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>

        {/* Steps Animation Wrapp */}
        <div
          data-w-id="e22a8e64-76c5-ec90-dab3-4caedf46f99d"
          className="w-layout-vflex steps-animation-wrapp"
        >
          <div
            data-w-id="e22a8e64-76c5-ec90-dab3-4caedf46f99e"
            className="w-layout-vflex steps-animation-track"
          >
            <section className="section steps-section">
              <div className="padding_global">
                <div className="w-layout-vflex container">
                  <div className="w-layout-vflex steps-section_heading animate-block_appear">
                    <div className="w-layout-vflex section_heading">
                      <div
                        data-wf--section-chips--variant="green"
                        className="section_chips w-variant-f8d39699-44e3-ff8a-4bbe-457969ecd496"
                      >
                        <img
                          loading="lazy"
                          src="images/6a2c17afc314109f37258f0f_28976eb8638efddb2ffb91df9feb710f_Arrow%20Icon.svg"
                          alt=""
                          className="icon_chips"
                        />
                        <div>Every workflow</div>
                      </div>
                      <div className="w-layout-vflex steps_title">
                        <h2 className="title--l">Every part of the sale. Handled.</h2>
                        <div className="w-layout-vflex steps_sub">
                          <p className="text--l">
                            Every workflow in your sales motion — researched, executed, tracked, and
                            followed through. Automatically.
                          </p>
                        </div>
                      </div>
                    </div>
                    <a
                      data-modal-open=""
                      data-wf--button--variant="primary-m"
                      href="/how-it-works"
                      className="button w-inline-block"
                    >
                      <div>Learn more</div>
                    </a>
                  </div>
                </div>
              </div>
              <div className="padding_global">
                <div className="w-layout-vflex container">
                  <div className="steps-wrapp">
                    <div className="w-layout-vflex step-container">
                      <div className="steps-track">
                        <div className="step_item">
                          <div className="step_icon">
                            <img
                              src="images/699c89b81528d48f5ad1da0c_Logo.svg"
                              loading="lazy"
                              alt=""
                              className="step_logo"
                            />
                          </div>
                          <div className="w-layout-vflex step_content">
                            <div className="text--70">Research</div>
                            <div className="w-layout-vflex step_sub">
                              <div className="text--l">
                                Every prospect researched before you reach out.
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="step_item">
                          <div className="step_icon">
                            <img
                              src="images/699c89b81528d48f5ad1da0c_Logo.svg"
                              loading="lazy"
                              alt=""
                              className="step_logo"
                            />
                          </div>
                          <div className="w-layout-vflex step_content">
                            <div className="text--70">Outreach</div>
                            <div className="w-layout-vflex step_sub">
                              <div className="text--l">
                                Every message drafted, sent, and followed through.
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="step_item">
                          <div className="step_icon">
                            <img
                              src="images/699c89b81528d48f5ad1da0c_Logo.svg"
                              loading="lazy"
                              alt=""
                              className="step_logo"
                            />
                          </div>
                          <div className="w-layout-vflex step_content">
                            <div className="text--70">Meetings</div>
                            <div className="w-layout-vflex step_sub">
                              <div className="text--l">
                                Every call prepped, recorded, and summarized.
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="step_item">
                          <div className="step_icon">
                            <img
                              src="images/699c89b81528d48f5ad1da0c_Logo.svg"
                              loading="lazy"
                              alt=""
                              className="step_logo"
                            />
                          </div>
                          <div className="w-layout-vflex step_content">
                            <div className="text--70">Follow-Up</div>
                            <div className="w-layout-vflex step_sub">
                              <div className="text--l">
                                Every pending action tracked and handled.
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="step_item">
                          <div className="step_icon">
                            <img
                              src="images/699c89b81528d48f5ad1da0c_Logo.svg"
                              loading="lazy"
                              alt=""
                              className="step_logo"
                            />
                          </div>
                          <div className="w-layout-vflex step_content">
                            <div className="text--70">CRM Sync</div>
                            <div className="w-layout-vflex step_sub">
                              <div className="text--l">
                                Every interaction captured. CRM always current.
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="step_item">
                          <div className="step_icon">
                            <img
                              src="images/699c89b81528d48f5ad1da0c_Logo.svg"
                              loading="lazy"
                              alt=""
                              className="step_logo"
                            />
                          </div>
                          <div className="w-layout-vflex step_content">
                            <div className="text--70">Pipeline</div>
                            <div className="w-layout-vflex step_sub">
                              <div className="text--l">
                                Every deal monitored. Every risk surfaced early.
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="step-line"></div>
                  </div>
                </div>
              </div>
            </section>
          </div>

          {/* Sales Section */}
          <div className="w-layout-vflex sales-animation-track">
            <section className="section sales-section">
              <div className="padding_global">
                <div className="w-layout-vflex container">
                  <div className="w-layout-vflex sales-section_heading">
                    <div className="w-layout-vflex section_heading">
                      <div data-wf--section-chips--variant="base" className="section_chips">
                        <img
                          loading="lazy"
                          src="images/6a2baff6be86b18d52d34a87_678c4ed9c7f0fe2b3dbca4429bca2c4b_Icon3.svg"
                          alt=""
                          className="icon_chips"
                        />
                        <div>Gets smarter every deal</div>
                      </div>
                      <div className="w-layout-vflex sales-section_title">
                        <h2 className="title--l">
                          <span className="text--grad">The only sales team</span> that gets better
                          the longer it works for you
                        </h2>
                        <div className="w-layout-vflex sales-section_sub">
                          <p className="text--l">
                            Most tools forget everything the moment you log out. Zig remembers every
                            call, every deal, every signal — and uses it to make the next move
                            sharper.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="padding_global">
                <div className="w-layout-vflex container">
                  <div className="sales-cards">
                    <div className="sales-cards_track">
                      <div className="sales-card">
                        <div className="title--s is--green">Month 1</div>
                        <div className="title--xs">
                          Learns how you sell Your CRM, deals, and ICPs. From day one.
                        </div>
                      </div>
                      <div className="sales-card">
                        <div className="title--s is--green">Month 3</div>
                        <div className="title--xs">
                          Spots what closes Patterns across your best reps, automatically.
                        </div>
                      </div>
                      <div className="sales-card">
                        <div className="title--s is--green">Month 4</div>
                        <div className="title--xs">
                          Flags risk before you feel it Stalled deals surfaced before they're gone.
                        </div>
                      </div>
                      <div className="sales-card">
                        <div className="title--s is--green">Month 6</div>
                        <div className="title--xs">
                          Knows more than any new hire could No ramp. No knowledge gap.
                        </div>
                      </div>
                      <div className="sales-card is--cta">
                        <div className="title--s">
                          Start today. Because in 6 months, today is what you'll wish you'd done.
                        </div>
                        <div className="w-layout-vflex sales-card_btns">
                          <a
                            data-modal-open=""
                            data-wf--button--variant="secondary-m"
                            href="/book-a-meeting"
                            className="button w-variant-81780053-53ab-86ef-2544-04e67f3b68aa w-inline-block"
                          >
                            <div>Start Now</div>
                          </a>
                          <a
                            data-modal-open=""
                            data-wf--button--variant="tertiary-m-white"
                            href="/book-a-meeting"
                            className="button w-variant-6101740f-88aa-0a0a-23a7-024ce8ee2b35 w-inline-block"
                          >
                            <div>Book a demo for a Team</div>
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="w-layout-vflex sales-figure-wrapp">
                <div className="sales-figure-wheel">
                  <div className="sales-figure-line is--1"></div>
                  <div className="sales-figure-line is--2"></div>
                  <div className="sales-figure-line is--3"></div>
                  <div className="sales-figure-line is--4"></div>
                  <div className="sales-figure-line is--5"></div>
                  <div className="sales-figure-line is--6"></div>
                </div>
              </div>
            </section>
          </div>
        </div>

        {/* Testimonials Section */}
        <section className="section testimonials">
          <div className="padding_global">
            <div className="w-layout-vflex container is--relative">
              <img
                src="images/6a2fef7294d8db83d0ec56aa_d79dbe81e56d37bc949d243b9016ae15_Pattern2.png"
                loading="lazy"
                sizes="100vw"
                srcSet="images/6a2fef7294d8db83d0ec56aa_d79dbe81e56d37bc949d243b9016ae15_Pattern2-p-500.png 500w, images/6a2fef7294d8db83d0ec56aa_d79dbe81e56d37bc949d243b9016ae15_Pattern2-p-800.png 800w, images/6a2fef7294d8db83d0ec56aa_d79dbe81e56d37bc949d243b9016ae15_Pattern2-p-1080.png 1080w, images/6a2fef7294d8db83d0ec56aa_d79dbe81e56d37bc949d243b9016ae15_Pattern2-p-1600.png 1600w, images/6a2fef7294d8db83d0ec56aa_d79dbe81e56d37bc949d243b9016ae15_Pattern2.png 1756w"
                alt=""
                className="testim-section_bg"
              />
              <div className="w-layout-vflex section_heading animate-block_appear">
                <div
                  data-wf--section-chips--variant="dark"
                  className="section_chips w-variant-28ba76d0-08d9-d4d7-40be-ef11d536cd9f"
                >
                  <img
                    loading="lazy"
                    src="images/6a2fef15ca223b3103a3fe46_Star%20Icon.svg"
                    alt=""
                    className="icon_chips"
                  />
                  <div>Testimonials</div>
                </div>
                <div className="w-layout-vflex sales-section_title">
                  <h2 className="title--l">What Our Clients Say</h2>
                </div>
              </div>
              <div className="w-layout-vflex main_grid">
                <div
                  id="w-node-e22a8e64-76c5-ec90-dab3-4caedf46fa2d-62a4fde0"
                  className="testim_slider splide"
                >
                  <div className="testim-slider_track splide__track w-dyn-list">
                    <div role="list" className="testim-slider_list splide__list w-dyn-items">
                      <div
                        role="listitem"
                        className="testim-slider_slide splide__slide w-dyn-item"
                      >
                        <p className="title--m">
                          "Zig.ai has significantly increased our outbound success. It helps us
                          identify our ideal customers, enrich our data, deliver the right message,
                          and reach prospects through the right channels all within one platform."
                        </p>
                        <div className="w-layout-vflex testim-slide_content">
                          <div className="testim-slider_person">
                            <img
                              src="images/6a5e0153c6ae04d19e1de34b_Rectangle%201614426176.jpg"
                              loading="lazy"
                              width="88"
                              height="88"
                              alt="Ketch"
                              className="slide_avatar"
                            />
                            <div className="slider_person-name">
                              <div className="title--s">Stéphane Le Mentec</div>
                              <div className="text--m opacity-60">
                                Director of Demand Generation, Ketch
                              </div>
                            </div>
                          </div>
                          <img
                            src="images/6a5e01672d674546bb2fc5e6_Ketch%20Logo2.svg"
                            loading="lazy"
                            alt="Ketch"
                            className="testim-slider_logo"
                          />
                        </div>
                      </div>
                      <div
                        role="listitem"
                        className="testim-slider_slide splide__slide w-dyn-item"
                      >
                        <p className="title--m">
                          "Best-in-Class AI GTM Assistant with Clean UI and Smart Prompts"
                        </p>
                        <div className="w-layout-vflex testim-slide_content">
                          <div className="testim-slider_person">
                            <img
                              src="images/6a5e010813ea68946c35f383_Rectangle%201614426177.jpg"
                              loading="lazy"
                              width="88"
                              height="88"
                              alt="Velociti"
                              className="slide_avatar"
                            />
                            <div className="slider_person-name">
                              <div className="title--s">Anthony Argenziano</div>
                              <div className="text--m opacity-60">Founder & CEO, Velociti</div>
                            </div>
                          </div>
                          <img
                            src="images/6a5e013ac9f2ccc48ff76e6e_Velociti%20Logo2.svg"
                            loading="lazy"
                            alt="Velociti"
                            className="testim-slider_logo"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="slider_arrows splide__arrows splide__arrows--ltr">
                    <div className="slider_arrow splide__arrow splide__arrow--prev">
                      <div className="arrow_icon w-embed">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="100%"
                          height="100%"
                          viewBox="0 0 20 18"
                          fill="none"
                          preserveAspectRatio="xMidYMid meet"
                          aria-hidden="true"
                          role="img"
                        >
                          <path
                            d="M19.1621 8.64086H0.750114M8.64097 0.75L0.750114 8.64086L8.64097 16.5317"
                            stroke="currentColor"
                            strokeWidth="1.5"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                      </div>
                    </div>
                    <div className="slider_arrow splide__arrow splide__arrow--next">
                      <div className="arrow_icon w-embed">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="100%"
                          height="100%"
                          viewBox="0 0 20 18"
                          fill="none"
                          preserveAspectRatio="xMidYMid meet"
                          aria-hidden="true"
                          role="img"
                        >
                          <path
                            d="M0.75 8.64086H19.162M11.2711 0.75L19.162 8.64086L11.2711 16.5317"
                            stroke="currentColor"
                            strokeWidth="1.5"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="section main">
          <div className="padding_global">
            <div className="w-layout-vflex container">
              <div className="w-layout-vflex main_grid">
                <div
                  id="w-node-e22a8e64-76c5-ec90-dab3-4caedf46fa43-62a4fde0"
                  className="w-layout-vflex faq_section-title"
                >
                  <h2 className="title--l">FAQ</h2>
                  <div className="text--l">Something we didn't cover? Talk to us.</div>
                </div>
                <div
                  id="w-node-e22a8e64-76c5-ec90-dab3-4caedf46fa48-62a4fde0"
                  className="faq_accordion-list"
                >
                  <div className="accordion">
                    <div className="accordion-control">
                      <div className="title--s">
                        I already use Salesforce, Gong, and Apollo. Do I have to give them up?
                      </div>
                      <div className="accordion-icon">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="100%"
                          viewBox="0 0 24 24"
                          fill="none"
                          className="accordion-icon_plus"
                        >
                          <path
                            d="M12 5V19M5 12H19"
                            stroke="#15171A"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="100%"
                          viewBox="0 0 24 24"
                          fill="none"
                          className="accordion-icon_minus"
                        >
                          <path
                            d="M5 12H19"
                            stroke="#15171A"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                      </div>
                    </div>
                    <div className="accordion-content">
                      <div className="w-layout-vflex accordion-content-text">
                        <div className="text--l">
                          No. Your assistants connect to the tools you already use — CRM, inbox,
                          calendar, outreach platforms. Zig reads what's there and starts working
                          from day one. No migration, no rip-and-replace.
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="accordion">
                    <div className="accordion-control">
                      <div className="title--s">Can I use Zig from my phone or by voice?</div>
                      <div className="accordion-icon">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="100%"
                          viewBox="0 0 24 24"
                          fill="none"
                          className="accordion-icon_plus"
                        >
                          <path
                            d="M12 5V19M5 12H19"
                            stroke="#15171A"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="100%"
                          viewBox="0 0 24 24"
                          fill="none"
                          className="accordion-icon_minus"
                        >
                          <path
                            d="M5 12H19"
                            stroke="#15171A"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                      </div>
                    </div>
                    <div className="accordion-content">
                      <div className="w-layout-vflex accordion-content-text">
                        <div className="text--l">
                          Yes. The ZigMobile app lets you command your assistants from anywhere —
                          scan a badge, send a voice update, approve an outreach sequence. Your team
                          travels with you.
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="accordion">
                    <div className="accordion-control">
                      <div className="title--s">
                        How quickly does it start doing useful work?
                      </div>
                      <div className="accordion-icon">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="100%"
                          viewBox="0 0 24 24"
                          fill="none"
                          className="accordion-icon_plus"
                        >
                          <path
                            d="M12 5V19M5 12H19"
                            stroke="#15171A"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="100%"
                          viewBox="0 0 24 24"
                          fill="none"
                          className="accordion-icon_minus"
                        >
                          <path
                            d="M5 12H19"
                            stroke="#15171A"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                      </div>
                    </div>
                    <div className="accordion-content">
                      <div className="w-layout-vflex accordion-content-text">
                        <div className="text--l">
                          Most reps see their first output — a lead list, a morning brief, or a
                          drafted follow-up — within 24 hours of connecting their CRM. Zig
                          compounds. The more it runs, the sharper it gets.
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="accordion">
                    <div className="accordion-control">
                      <div className="title--s">
                        My reps won't adopt another tool — and will they actually be in control?
                      </div>
                      <div className="accordion-icon">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="100%"
                          viewBox="0 0 24 24"
                          fill="none"
                          className="accordion-icon_plus"
                        >
                          <path
                            d="M12 5V19M5 12H19"
                            stroke="#15171A"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="100%"
                          viewBox="0 0 24 24"
                          fill="none"
                          className="accordion-icon_minus"
                        >
                          <path
                            d="M5 12H19"
                            stroke="#15171A"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                      </div>
                    </div>
                    <div className="accordion-content">
                      <div className="w-layout-vflex accordion-content-text">
                        <div className="text--l">
                          They don't have to open it, and they never lose control. Zig works through
                          the surfaces your reps already use — email, Slack, their phone. The
                          assistants handle the work in the background: drafting, preparing,
                          proposing. Reps get one tap to approve before anything goes out. No new
                          interface to learn. No risk of something sending without them knowing.
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="accordion">
                    <div className="accordion-control">
                      <div className="title--s">How does Zig get smarter over time?</div>
                      <div className="accordion-icon">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="100%"
                          viewBox="0 0 24 24"
                          fill="none"
                          className="accordion-icon_plus"
                        >
                          <path
                            d="M12 5V19M5 12H19"
                            stroke="#15171A"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="100%"
                          viewBox="0 0 24 24"
                          fill="none"
                          className="accordion-icon_minus"
                        >
                          <path
                            d="M5 12H19"
                            stroke="#15171A"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                      </div>
                    </div>
                    <div className="accordion-content">
                      <div className="w-layout-vflex accordion-content-text">
                        <div className="text--l">
                          Every call, email, and deal adds to what your assistants know about your
                          team, your buyers, and what closes. At month 12, they know your pipeline
                          better than a new hire could in their first year. That's the compounding
                          effect — and it's yours.
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="accordion">
                    <div className="accordion-control">
                      <div className="title--s">Who is Zig built for?</div>
                      <div className="accordion-icon">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="100%"
                          viewBox="0 0 24 24"
                          fill="none"
                          className="accordion-icon_plus"
                        >
                          <path
                            d="M12 5V19M5 12H19"
                            stroke="#15171A"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="100%"
                          viewBox="0 0 24 24"
                          fill="none"
                          className="accordion-icon_minus"
                        >
                          <path
                            d="M5 12H19"
                            stroke="#15171A"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                      </div>
                    </div>
                    <div className="accordion-content">
                      <div className="w-layout-vflex accordion-content-text">
                        <div className="text--l">
                          Any rep who spends too much time on work that isn't selling. Any leader
                          who's tired of pipeline reviews that don't reflect reality. From a solo
                          founder doing their own outreach to a VP running a team of fifty.
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="accordion">
                    <div className="accordion-control">
                      <div className="title--s">How does Zig price — is it per seat?</div>
                      <div className="accordion-icon">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="100%"
                          viewBox="0 0 24 24"
                          fill="none"
                          className="accordion-icon_plus"
                        >
                          <path
                            d="M12 5V19M5 12H19"
                            stroke="#15171A"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="100%"
                          viewBox="0 0 24 24"
                          fill="none"
                          className="accordion-icon_minus"
                        >
                          <path
                            d="M5 12H19"
                            stroke="#15171A"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                      </div>
                    </div>
                    <div className="accordion-content">
                      <div className="w-layout-vflex accordion-content-text">
                        <div className="text--l">
                          No per-seat charges. You pre-buy a pool of executions — the work your
                          assistants actually do. Unused executions carry forward. You pay for
                          output, not headcount.
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Footer Section */}
        <section className="footer-section">
          <div className="w-layout-vflex footer-top">
            <div className="padding_global">
              <div className="w-layout-vflex container">
                <div className="w-layout-vflex flex-block-24">
                  <div className="w-layout-vflex flex-block-25">
                    <h2 className="title--l">Stop managing tools. Start executing.</h2>
                    <div className="text--l">
                      Every day without Zig is 40 minutes per rep you're not getting back.
                    </div>
                  </div>
                  <div className="w-layout-vflex steps-btns">
                    <a
                      data-modal-open=""
                      data-wf--button--variant="primary-m"
                      href="/book-a-meeting"
                      className="button w-inline-block"
                    >
                      <div>Start Now</div>
                    </a>
                    <a
                      data-modal-open=""
                      data-wf--button--variant="tertiary-m-white"
                      href="/book-a-meeting"
                      className="button w-variant-6101740f-88aa-0a0a-23a7-024ce8ee2b35 w-inline-block"
                    >
                      <div>Book a demo for a Team</div>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="w-layout-vflex footer-bottom">
            <div className="padding_global">
              <div className="w-layout-vflex container">
                <div className="footer_container-grid">
                  <div
                    id="w-node-dfeb8a6f-3d27-8a65-53e0-41b223156485-23156472"
                    className="w-layout-vflex footer-logo_wrapp"
                  >
                    <a
                      href="/"
                      aria-current="page"
                      className="footer_logo w-inline-block w--current"
                    >
                      <img
                        width="128"
                        height="37"
                        alt="Zig logo"
                        src="images/6a2ae0c52c00f4b73a109602_Tag%20Icon.svg"
                        loading="eager"
                        className="logo_img"
                      />
                    </a>
                    <div className="text--s is--green--200">
                      © 2026 zig.ai. All rights reserved
                      <br />
                    </div>
                  </div>
                  <div className="w-layout-vflex footer_column-links">
                    <div className="w-layout-vflex footer_links-list">
                      <a href="/how-it-works" className="text--link is--white">
                        How It Works
                      </a>
                      <a href="/pricing" className="text--link is--white">
                        Pricing
                      </a>
                      <a href="/about" className="text--link is--white">
                        About Zig
                      </a>
                      <a href="/blog" className="text--link is--white">
                        Blog
                      </a>
                    </div>
                    <div
                      id="w-node-dfeb8a6f-3d27-8a65-53e0-41b223156495-23156472"
                      className="w-layout-vflex footer_links-wrapp"
                    >
                      <div className="w-layout-vflex footer_links-list">
                        <a href="/privacy-policy" className="text--link is--white">
                          Privacy Policy
                        </a>
                        <a href="/terms-of-service" className="text--link is--white">
                          Terms of Services
                        </a>
                        <a
                          href="https://trust.zig.ai/"
                          target="_blank"
                          className="text--link is--white"
                        >
                          Security
                        </a>
                      </div>
                    </div>
                  </div>
                  <div
                    id="w-node-dfeb8a6f-3d27-8a65-53e0-41b22315649d-23156472"
                    className="w-layout-vflex footer_sn-wrapp"
                  >
                    <div className="footer_sn-list">
                      <a
                        aria-label="LinkedIn"
                        href="https://www.linkedin.com/company/zigai/"
                        target="_blank"
                        className="footer_sn-link w-inline-block"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="100%"
                          viewBox="0 0 38 38"
                          fill="none"
                          className="footer_sn-icon"
                        >
                          <rect
                            width="38.005"
                            height="37.99"
                            rx="8"
                            fill="#08906C"
                            className="rect"
                          />
                          <path
                            d="M12.1606 14.3212C13.3609 14.3212 14.3212 13.3459 14.3212 12.1606C14.3212 10.9753 13.3459 10 12.1606 10C10.9753 10 10 10.9753 10 12.1606C10 13.3459 10.9753 14.3212 12.1606 14.3212ZM16.3768 15.9567V27.99H20.0978V22.0483C20.0978 20.4729 20.3979 18.9575 22.3334 18.9575C24.269 18.9575 24.269 20.758 24.269 22.1384V27.99H28.005V21.3882C28.005 18.1473 27.3148 15.6566 23.5338 15.6566C21.7183 15.6566 20.5029 16.6468 20.0078 17.5921H19.9628V15.9417H16.3918L16.3768 15.9567ZM10.3001 15.9567H14.0361V27.99H10.3001V15.9567Z"
                            fill="#F2F6F5"
                          />
                        </svg>
                      </a>
                      <a
                        aria-label="YouTube"
                        href="http://www.youtube.com/@Zig-ai-for-sales"
                        target="_blank"
                        className="footer_sn-link w-inline-block"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="100%"
                          viewBox="0 0 38 38"
                          fill="none"
                          className="footer_sn-icon"
                        >
                          <g opacity="0.89">
                            <rect width="38" height="38" rx="8" fill="#08906C" />
                            <path
                              d="M16.8064 22.2637V15.7363L22.5114 18.992L16.8064 22.2637ZM29.5341 13.7669C29.2769 12.8299 28.5537 12.0993 27.5895 11.8452C25.8861 11.3846 18.992 11.3846 18.992 11.3846C18.992 11.3846 12.114 11.3846 10.4105 11.8452C9.46236 12.0993 8.72314 12.8299 8.44996 13.7669C8 15.4504 8 18.992 8 18.992C8 18.992 8 22.5337 8.44996 24.2331C8.72314 25.1542 9.46236 25.9006 10.4105 26.1548C12.114 26.6154 18.992 26.6154 18.992 26.6154C18.992 26.6154 25.8861 26.6154 27.5895 26.1548C28.5537 25.9006 29.2769 25.1542 29.5341 24.2331C30 22.5337 30 18.992 30 18.992C30 18.992 30 15.4504 29.5341 13.7669Z"
                              fill="#F2F6F5"
                            />
                          </g>
                        </svg>
                      </a>
                      <a
                        aria-label="TikTok"
                        href="https://www.tiktok.com/@zig.ai?_r=1&_t=ZT-93cSWxNDVnB"
                        target="_blank"
                        className="footer_sn-link w-inline-block"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="100%"
                          viewBox="0 0 38 38"
                          fill="none"
                          className="footer_sn-icon"
                        >
                          <rect width="38" height="38" rx="8" fill="#08906C" />
                          <g clipPath="url(#clip0_1069_3263)">
                            <path
                              d="M23.1659 8.4375V8.90255C23.2691 10.0353 23.7459 11.0599 24.472 11.8528C25.1704 12.615 26.0992 13.163 27.1485 13.3864L27.2793 13.4125C27.5852 13.469 27.8959 13.4974 28.2072 13.4973V17.1129C26.3274 17.1129 24.5869 16.5155 23.1661 15.5005V22.8786C23.1661 26.5698 20.1723 29.5616 16.4794 29.5616C14.6061 29.5616 12.9128 28.792 11.6986 27.5511C10.5194 26.3463 9.79297 24.6974 9.79297 22.8785C9.79299 19.2348 12.7106 16.2722 16.3384 16.1972L16.3385 16.1971C16.6922 16.1896 17.0462 16.21 17.3968 16.258V19.9544C17.0968 19.8592 16.7837 19.8111 16.4689 19.8112C14.7796 19.8112 13.4103 21.1799 13.4103 22.868C13.4093 23.5367 13.6285 24.1871 14.0342 24.7188C13.0361 24.2153 14.0342 25.9126 14.0342 24.7188C13.0362 24.2153 14.0342 25.9124 14.0342 24.7188C14.5931 25.4519 15.4754 25.9251 16.4688 25.9251C18.1545 25.9251 19.5214 24.562 19.5274 22.8785V8.4375H23.1659Z"
                              fill="#F2F6F5"
                            />
                          </g>
                          <defs>
                            <clipPath id="clip0_1069_3263">
                              <rect
                                width="22"
                                height="22"
                                fill="white"
                                transform="translate(8 8)"
                              />
                            </clipPath>
                          </defs>
                        </svg>
                      </a>
                    </div>
                    <a
                      href="https://peppermint.global"
                      target="_blank"
                      className="footer_link-agency w-inline-block"
                    >
                      <div className="text--s is--medium">Website designed by</div>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="100%"
                        viewBox="0 0 126 23"
                        fill="none"
                        className="peppermint_logo"
                      >
                        <path
                          d="M9.02148 0C13.8819 0 17.8368 3.70913 17.8369 8.26855C17.8369 12.8281 13.8825 16.5381 9.02148 16.5381H5.76562C5.75383 16.5381 5.74273 16.5425 5.73438 16.5508L0.0751953 22.1143C0.0472477 22.1415 0.000207017 22.122 0 22.083V0.0439453C8.26648e-05 0.0196022 0.0195573 0.000138927 0.0439453 0H9.02148ZM51.625 6.32812C52.9243 6.32812 53.938 6.68199 54.6641 7.38867C55.3899 8.09531 55.7529 9.26499 55.7529 10.8955C55.7529 12.5263 55.377 13.7465 54.626 14.5557C53.8739 15.3648 52.8481 15.7695 51.5488 15.7695C50.4526 15.7695 49.5165 15.5153 48.7393 15.0049V19.3203H46.6562V6.51953H48.4521L48.5674 7.41797C48.9753 7.0487 49.421 6.77455 49.9053 6.5957C50.3895 6.41785 50.9629 6.32815 51.625 6.32812ZM62.3672 6.32812C63.6665 6.32812 64.6802 6.68199 65.4062 7.38867C66.1321 8.09531 66.4951 9.26499 66.4951 10.8955C66.4951 12.5263 66.1192 13.7465 65.3682 14.5557C64.616 15.3648 63.5903 15.7695 62.291 15.7695C61.1948 15.7695 60.2587 15.5153 59.4814 15.0049V19.3203H57.3984V6.51953H59.1943L59.3096 7.41797C59.7175 7.0487 60.1632 6.77455 60.6475 6.5957C61.1317 6.41785 61.7051 6.32815 62.3672 6.32812ZM40.8672 6.23438C42.2429 6.23438 43.2785 6.5952 43.9736 7.31445C44.6677 8.03466 45.0146 8.96175 45.0146 10.0957V11.7773H38.3828C38.4843 12.6559 38.8036 13.2621 39.3389 13.5928C39.8744 13.9244 40.6899 14.0898 41.7861 14.0898C42.2443 14.0898 42.716 14.0459 43.2002 13.957C43.6845 13.8681 44.1052 13.7525 44.4619 13.6123V15.1416C44.054 15.3204 43.5863 15.454 43.0576 15.543C42.5288 15.6319 41.9646 15.6768 41.3652 15.6768H41.3633C39.7838 15.6767 38.5595 15.288 37.6934 14.5107C36.8273 13.7335 36.3945 12.5421 36.3945 10.9365C36.3945 9.48371 36.7636 8.33712 37.5029 7.49609C38.2414 6.65511 39.3632 6.23445 40.8672 6.23438ZM72.2305 6.23438C73.6061 6.23438 74.6418 6.5952 75.3369 7.31445C76.031 8.03466 76.3779 8.96175 76.3779 10.0957V11.7773H69.7461C69.8476 12.6559 70.1668 13.2621 70.7021 13.5928C71.2377 13.9244 72.0531 14.0898 73.1494 14.0898C73.6075 14.0898 74.0793 14.0459 74.5635 13.957C75.0478 13.8681 75.4685 13.7525 75.8252 13.6123V15.1416C75.4173 15.3204 74.9496 15.454 74.4209 15.543C73.8921 15.6319 73.3279 15.6768 72.7285 15.6768H72.7266C71.147 15.6767 69.9228 15.288 69.0566 14.5107C68.1906 13.7335 67.7578 12.5421 67.7578 10.9365C67.7578 9.48371 68.1268 8.33712 68.8662 7.49609C69.6047 6.65511 70.7264 6.23446 72.2305 6.23438ZM123.256 8.0459H120.314V12.6709C120.314 13.1939 120.436 13.5598 120.679 13.7705C120.92 13.98 121.316 14.0849 121.863 14.085C122.207 14.085 122.571 14.0212 122.953 13.8936V15.3652C122.456 15.5692 121.851 15.6709 121.138 15.6709L121.136 15.6729C120.167 15.6729 119.443 15.4147 118.966 14.8984C118.488 14.3822 118.25 13.6783 118.25 12.7861V8.0459H115.445V6.42188H123.389L123.256 8.0459ZM31.3682 3.17578C32.3106 3.1758 33.0883 3.35428 33.7002 3.71094C34.312 4.06762 34.7638 4.55527 35.0576 5.17285C35.3505 5.79054 35.4971 6.49641 35.4971 7.28613C35.4969 8.50868 35.1181 9.4901 34.3604 10.2295C33.6025 10.9689 32.5795 11.3378 31.293 11.3379H27.9668V15.4854L25.8828 15.4844V3.17578H31.3682ZM83.375 7.82129C83.0184 7.88509 82.6324 7.97783 82.2188 8.09863C81.8053 8.21939 81.413 8.35317 81.0439 8.49902C80.6747 8.64597 80.3617 8.79551 80.1064 8.94922V15.4854H78.0234V6.42578H79.9346L80.0498 7.47656C80.4829 7.19623 80.9993 6.94101 81.5977 6.71191C82.1959 6.48287 82.7883 6.32331 83.375 6.23438V7.82129ZM110.895 6.23438C112.066 6.23438 112.921 6.50852 113.456 7.05566C113.992 7.6038 114.258 8.45807 114.258 9.61719V15.4854H112.194V9.71289C112.194 9.01201 112.051 8.52156 111.764 8.24121C111.477 7.96098 110.938 7.82129 110.148 7.82129C109.677 7.8213 109.214 7.91699 108.763 8.1084C108.311 8.29978 107.931 8.54815 107.626 8.85352V15.4854H105.543L105.544 15.4844V6.4248H107.455L107.551 7.38086C107.959 7.06282 108.446 6.79265 109.013 6.56934C109.579 6.34702 110.207 6.23441 110.895 6.23438ZM95.4707 6.23438C96.5157 6.2344 97.2863 6.50253 97.7832 7.03711C98.2799 7.57268 98.5283 8.39429 98.5283 9.50195V15.4844H96.4834V9.71191C96.4834 9.01105 96.3369 8.52059 96.0439 8.24023C95.7511 7.95991 95.2725 7.82034 94.6104 7.82031C94.1774 7.82031 93.7664 7.89618 93.3779 8.04883C92.9893 8.20157 92.6544 8.43085 92.374 8.7373C92.4127 8.87735 92.4376 9.02417 92.4502 9.17676C92.4628 9.32944 92.4697 9.49602 92.4697 9.67383V15.4844H90.5391V9.73145C90.5391 9.06944 90.4243 8.58479 90.1953 8.27832C89.9662 7.97283 89.5326 7.82031 88.8955 7.82031C88.449 7.82035 88.0251 7.92502 87.624 8.13477C87.2231 8.34445 86.8628 8.59693 86.5449 8.88965V15.4844H84.5V6.4248H86.4111L86.5068 7.38086C86.9525 7.02413 87.4439 6.74402 87.9785 6.54004C88.5141 6.33609 89.0873 6.23438 89.6982 6.23438C90.3478 6.23439 90.8543 6.34003 91.2178 6.5498C91.5812 6.75958 91.8574 7.04968 92.0488 7.41992C92.4693 7.07585 92.954 6.79263 93.502 6.56934C94.0501 6.34699 94.707 6.23438 95.4707 6.23438ZM103.499 15.4834H101.415V8.01074H100.039L100.23 6.42383H103.499V15.4834ZM51.0713 7.91504C50.1413 7.91505 49.3638 8.23402 48.7393 8.87109V13.4004C49.0321 13.643 49.3612 13.8374 49.7236 13.9834C50.0871 14.1303 50.5168 14.2031 51.0146 14.2031C52.7728 14.203 53.6513 13.0943 53.6514 10.8779C53.6514 9.80775 53.454 9.04521 53.0586 8.59277C52.6632 8.14062 52.001 7.91504 51.0713 7.91504ZM61.8135 7.91504C60.8835 7.91505 60.1059 8.23403 59.4814 8.87109V13.4004C59.7743 13.643 60.1034 13.8374 60.4658 13.9834C60.8293 14.1303 61.259 14.2031 61.7568 14.2031C63.515 14.203 64.3935 13.0943 64.3936 10.8779C64.3936 9.80775 64.1962 9.04521 63.8008 8.59277C63.4053 8.14062 62.7432 7.91504 61.8135 7.91504ZM27.9678 11.3359L29.5039 9.82227H30.7256C32.2036 9.82224 33.4139 8.69283 33.4141 7.31152C33.414 5.93009 32.2047 4.79983 30.7256 4.7998H27.9678V11.3359ZM40.9238 7.80273C39.9554 7.80273 39.2903 8.01225 38.9268 8.43262C38.5633 8.85308 38.3819 9.51529 38.3818 10.4199H43.1787V9.79004C43.1787 9.16554 43.0072 8.67808 42.6631 8.32812C42.3189 7.97819 41.7387 7.80275 40.9238 7.80273ZM72.2871 7.80273C71.3186 7.80273 70.6536 8.01226 70.29 8.43262C69.9266 8.85308 69.7452 9.51529 69.7451 10.4199H74.542V9.79004C74.542 9.16554 74.3705 8.67808 74.0264 8.32812C73.6822 7.97819 73.102 7.80275 72.2871 7.80273ZM103.518 4.53223H101.242V2.8125H103.518V4.53223Z"
                          fill="currentColor"
                        />
                      </svg>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Custom JS placeholder divs (scripts removed per rule 7) */}
      <div className="w-layout-vflex custom_js">
        <div className="modal-logic_js w-embed w-script"></div>
        <div className="gsap w-embed w-script"></div>
        <div className="lenis-scroll-js w-embed w-script"></div>
        <div className="hero-lottie-js w-embed w-script"></div>
        <div className="text-animation-js w-embed w-script"></div>
        <div className="impact-circles-js w-embed w-script"></div>
        <div className="win-circles-js w-embed w-script"></div>
        <div className="body-bg-js w-embed w-script"></div>
        <div className="sales-section-js w-embed w-script"></div>
        <div className="testimonials-js w-embed w-script"></div>
        <div className="navbar-bg-js w-embed w-script"></div>
        <div className="faq-js w-embed w-script"></div>
      </div>
    </div>
  );
};

export default App;